package ru.refactorum.drug.menu;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.jetbrains.annotations.NotNull;

import java.util.Objects;

public final class DrugShopHolder implements InventoryHolder {

    private final MenuType menuType;
    private final int pageIndex;
    private final String entryId;
    private Inventory inventory;

    public DrugShopHolder(final MenuType menuType, final int pageIndex, final String entryId) {
        this.menuType = menuType;
        this.pageIndex = pageIndex;
        this.entryId = entryId;
    }

    @Override
    public @NotNull Inventory getInventory() {
        return Objects.requireNonNull(inventory, "inventory has not been initialized yet");
    }

    public void setInventory(final Inventory inventory) {
        this.inventory = inventory;
    }

    public MenuType menuType() {
        return menuType;
    }

    public int pageIndex() {
        return pageIndex;
    }

    public String entryId() {
        return entryId;
    }

    public String substanceId() {
        return entryId;
    }

    public String remedyId() {
        return entryId;
    }
}

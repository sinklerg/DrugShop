package ru.refactorum.drug.model;

import org.bukkit.Material;

import java.util.Collections;
import java.util.List;

public final class Remedy {

    private final String id;
    private final int slot;
    private final Material material;
    private final int amount;
    private final double price;
    private final String permission;
    private final boolean hideWithoutPermission;
    private final int customModelData;
    private final String displayName;
    private final List<String> lore;
    private final int overdoseDecrease;
    private final int addictionDecrease;
    private final List<EffectSpec> effects;

    public Remedy(
            final String id,
            final int slot,
            final Material material,
            final int amount,
            final double price,
            final String permission,
            final boolean hideWithoutPermission,
            final int customModelData,
            final String displayName,
            final List<String> lore,
            final int overdoseDecrease,
            final int addictionDecrease,
            final List<EffectSpec> effects
    ) {
        this.id = id;
        this.slot = slot;
        this.material = material;
        this.amount = Math.max(1, Math.min(64, amount));
        this.price = Math.max(0D, price);
        this.permission = permission == null ? "" : permission;
        this.hideWithoutPermission = hideWithoutPermission;
        this.customModelData = Math.max(0, customModelData);
        this.displayName = displayName == null ? id : displayName;
        this.lore = lore == null ? Collections.emptyList() : List.copyOf(lore);
        this.overdoseDecrease = Math.max(0, overdoseDecrease);
        this.addictionDecrease = Math.max(0, addictionDecrease);
        this.effects = effects == null ? Collections.emptyList() : List.copyOf(effects);
    }

    public String id() {
        return id;
    }

    public int slot() {
        return slot;
    }

    public Material material() {
        return material;
    }

    public int amount() {
        return amount;
    }

    public double price() {
        return price;
    }

    public String permission() {
        return permission;
    }

    public boolean hasPermissionRestriction() {
        return !permission.isBlank();
    }

    public boolean hideWithoutPermission() {
        return hideWithoutPermission;
    }

    public int customModelData() {
        return customModelData;
    }

    public String displayName() {
        return displayName;
    }

    public List<String> lore() {
        return lore;
    }

    public int overdoseDecrease() {
        return overdoseDecrease;
    }

    public int addictionDecrease() {
        return addictionDecrease;
    }

    public List<EffectSpec> effects() {
        return effects;
    }
}

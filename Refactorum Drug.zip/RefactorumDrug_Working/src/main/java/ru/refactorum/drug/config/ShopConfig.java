package ru.refactorum.drug.config;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.potion.PotionEffectType;
import ru.refactorum.drug.RefactorumDrugPlugin;
import ru.refactorum.drug.model.EffectSpec;
import ru.refactorum.drug.model.Remedy;
import ru.refactorum.drug.model.ShopPage;
import ru.refactorum.drug.model.Substance;
import ru.refactorum.drug.util.ConfigUtil;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;

public final class ShopConfig {

    private final RefactorumDrugPlugin plugin;
    private final String pluginDisplayName;
    private final String usePermission;
    private final String adminPermission;
    private final int consumeCooldownSeconds;
    private final boolean dropOverflowItems;
    private final boolean useSoundEnabled;
    private final String useSoundName;
    private final float useSoundVolume;
    private final float useSoundPitch;
    private final CurrencySettings currency;
    private final ShopGuiSettings shopGui;
    private final RemedyGuiSettings remedyGui;
    private final PurchaseGuiSettings purchaseGui;
    private final PurchaseGuiSettings remedyPurchaseGui;
    private final AddictionSettings addiction;
    private final OverdoseSettings overdose;
    private final List<ShopPage> pages;
    private final Map<String, ShopPage> pagesById;
    private final Map<String, Substance> substancesById;
    private final Map<String, Remedy> remediesById;

    public ShopConfig(final RefactorumDrugPlugin plugin, final FileConfiguration config) {
        this.plugin = plugin;
        this.pluginDisplayName = config.getString("settings.display-name", "&7&lRefactorum&d&lDrug");
        this.usePermission = config.getString("settings.use-permission", "drugshop.use");
        this.adminPermission = config.getString("settings.admin-permission", "drugshop.admin");
        this.consumeCooldownSeconds = Math.max(0, config.getInt("settings.consume-cooldown-seconds", 5));
        this.dropOverflowItems = config.getBoolean("settings.drop-overflow-items", true);
        this.useSoundEnabled = config.getBoolean("settings.use-sound.enabled", true);
        this.useSoundName = config.getString("settings.use-sound.sound", "ENTITY_GENERIC_DRINK");
        this.useSoundVolume = (float) config.getDouble("settings.use-sound.volume", 0.8D);
        this.useSoundPitch = (float) config.getDouble("settings.use-sound.pitch", 1.2D);
        this.currency = loadCurrency(config);
        this.shopGui = loadShopGui(config);
        this.remedyGui = loadRemedyGui(config);
        this.purchaseGui = loadPurchaseGui(config, "gui.purchase", "<dark_purple><bold>Покупка</bold></dark_purple> <dark_gray>|</dark_gray> {substance_name}");
        this.remedyPurchaseGui = loadPurchaseGui(config, "gui.remedy-purchase", "<green><bold>Покупка</bold></green> <dark_gray>|</dark_gray> {remedy_name}");
        this.addiction = loadAddiction(config);
        this.overdose = loadOverdose(config);
        this.pagesById = loadPages(config);
        this.pages = List.copyOf(this.pagesById.values());
        this.substancesById = loadSubstances(config);
        this.remediesById = loadRemedies(config);
    }

    private CurrencySettings loadCurrency(final FileConfiguration config) {
        final Material itemMaterial = parseMaterialWithWarning(
                "currency.item.material",
                config.getString("currency.item.material", config.getString("currency.material", "EMERALD")),
                Material.EMERALD
        );

        return new CurrencySettings(
                CurrencyMode.fromName(config.getString("currency.mode", "ITEM")),
                config.getString("currency.display-name", "<green>изумрудов</green>"),
                itemMaterial,
                config.getBoolean("currency.item.require-custom-model-data", config.getBoolean("currency.require-custom-model-data", false)),
                Math.max(0, config.getInt("currency.item.custom-model-data", config.getInt("currency.custom-model-data", 0))),
                config.getString("currency.amount-format", "#,##0.##"),
                config.getBoolean("currency.vault.use-vault-format", false)
        );
    }

    private ShopGuiSettings loadShopGui(final FileConfiguration config) {
        final int size = ConfigUtil.clampInventorySize(config.getInt("gui.shop.size", 54), 54);
        final ConfigurationSection fillSection = config.getConfigurationSection("gui.shop.fill");
        final ConfigurationSection buttons = config.getConfigurationSection("gui.shop.buttons");

        return new ShopGuiSettings(
                size,
                config.getString("gui.shop.title", "<dark_purple><bold>Магазин</bold></dark_purple> <dark_gray>|</dark_gray> <gray>{page_title}</gray> <dark_gray>({page}/{pages})</dark_gray>"),
                config.getBoolean("gui.shop.fill.enabled", true),
                ConfigItem.fromSection(fillSection, Material.BLACK_STAINED_GLASS_PANE),
                ButtonConfig.fromSection(buttons == null ? null : buttons.getConfigurationSection("previous"), 45, Material.ARROW),
                ButtonConfig.fromSection(buttons == null ? null : buttons.getConfigurationSection("close"), 49, Material.BARRIER),
                ButtonConfig.fromSection(buttons == null ? null : buttons.getConfigurationSection("next"), 53, Material.ARROW),
                ButtonConfig.fromSection(buttons == null ? null : buttons.getConfigurationSection("remedies"), 48, Material.HONEY_BOTTLE),
                config.getStringList("gui.shop.price-lore")
        );
    }

    private RemedyGuiSettings loadRemedyGui(final FileConfiguration config) {
        final int size = ConfigUtil.clampInventorySize(config.getInt("gui.remedies.size", 54), 54);
        final ConfigurationSection fillSection = config.getConfigurationSection("gui.remedies.fill");
        final ConfigurationSection buttons = config.getConfigurationSection("gui.remedies.buttons");

        return new RemedyGuiSettings(
                size,
                config.getString("gui.remedies.title", "<green><bold>Стабилизаторы</bold></green>"),
                config.getBoolean("gui.remedies.fill.enabled", true),
                ConfigItem.fromSection(fillSection, Material.LIME_STAINED_GLASS_PANE),
                ButtonConfig.fromSection(buttons == null ? null : buttons.getConfigurationSection("back"), 45, Material.ARROW),
                ButtonConfig.fromSection(buttons == null ? null : buttons.getConfigurationSection("close"), 49, Material.BARRIER),
                config.getStringList("gui.remedies.price-lore")
        );
    }

    private PurchaseGuiSettings loadPurchaseGui(final FileConfiguration config, final String path, final String fallbackTitle) {
        final int size = ConfigUtil.clampInventorySize(config.getInt(path + ".size", 27), 27);
        final ConfigurationSection fillSection = config.getConfigurationSection(path + ".fill");
        final ConfigurationSection buttons = config.getConfigurationSection(path + ".buttons");

        return new PurchaseGuiSettings(
                size,
                config.getString(path + ".title", fallbackTitle),
                ConfigUtil.clampSlot(config.getInt(path + ".preview-slot", 13), size),
                config.getBoolean(path + ".close-after-buy", true),
                config.getBoolean(path + ".fill.enabled", true),
                ConfigItem.fromSection(fillSection, Material.PURPLE_STAINED_GLASS_PANE),
                ButtonConfig.fromSection(buttons == null ? null : buttons.getConfigurationSection("confirm"), 11, Material.LIME_CONCRETE),
                ButtonConfig.fromSection(buttons == null ? null : buttons.getConfigurationSection("back"), 15, Material.RED_CONCRETE)
        );
    }

    private AddictionSettings loadAddiction(final FileConfiguration config) {
        final ConfigurationSection withdrawalSection = config.getConfigurationSection("addiction.withdrawal");
        return new AddictionSettings(
                config.getBoolean("addiction.enabled", true),
                config.getInt("addiction.max-level", 100),
                config.getInt("addiction.default-gain", 8),
                config.getInt("addiction.thresholds.mild", 25),
                config.getInt("addiction.thresholds.strong", 60),
                config.getInt("addiction.thresholds.critical", 85),
                config.getInt("addiction.check-interval-seconds", 20),
                config.getBoolean("addiction.notify-on-use", true),
                config.getBoolean("addiction.withdrawal.enabled", true),
                config.getInt("addiction.withdrawal.min-level", 25),
                config.getInt("addiction.withdrawal.start-after-seconds", 180),
                config.getInt("addiction.withdrawal.interval-seconds", 45),
                config.getInt("addiction.withdrawal.message-cooldown-seconds", 120),
                loadEffects(withdrawalSection, "effects", "addiction.withdrawal.effects"),
                config.getBoolean("addiction.decay.enabled", true),
                config.getInt("addiction.decay.start-after-seconds", 300),
                config.getInt("addiction.decay.interval-seconds", 90),
                config.getInt("addiction.decay.amount", 2)
        );
    }

    private OverdoseSettings loadOverdose(final FileConfiguration config) {
        final ConfigurationSection warningSection = config.getConfigurationSection("overdose.stage-effects.warning");
        final ConfigurationSection badSection = config.getConfigurationSection("overdose.stage-effects.bad");
        final ConfigurationSection criticalSection = config.getConfigurationSection("overdose.stage-effects.critical");
        final ConfigurationSection badTripSection = config.getConfigurationSection("overdose.badtrip");

        return new OverdoseSettings(
                config.getBoolean("overdose.enabled", true),
                config.getInt("overdose.max-level", 100),
                config.getInt("overdose.default-gain", 18),
                config.getInt("overdose.reset-after-seconds", 120),
                config.getInt("overdose.check-interval-seconds", 20),
                config.getBoolean("overdose.notify-on-use", true),
                config.getInt("overdose.thresholds.warning", 35),
                config.getInt("overdose.thresholds.bad", 60),
                config.getInt("overdose.thresholds.critical", 85),
                loadEffects(warningSection, "effects", "overdose.stage-effects.warning.effects"),
                loadEffects(badSection, "effects", "overdose.stage-effects.bad.effects"),
                loadEffects(criticalSection, "effects", "overdose.stage-effects.critical.effects"),
                config.getBoolean("overdose.badtrip.enabled", true),
                config.getInt("overdose.badtrip.min-level", 75),
                config.getInt("overdose.badtrip.cooldown-seconds", 45),
                config.getDouble("overdose.badtrip.damage", 2D),
                loadEffects(badTripSection, "effects", "overdose.badtrip.effects"),
                config.getBoolean("overdose.decay.enabled", true),
                config.getInt("overdose.decay.start-after-seconds", 90),
                config.getInt("overdose.decay.interval-seconds", 30),
                config.getInt("overdose.decay.amount", 8)
        );
    }

    private Map<String, ShopPage> loadPages(final FileConfiguration config) {
        final ConfigurationSection pagesSection = config.getConfigurationSection("pages");
        if (pagesSection == null) {
            return Map.of();
        }

        final List<ShopPage> loadedPages = new ArrayList<>();
        for (String id : pagesSection.getKeys(false)) {
            final ConfigurationSection pageSection = pagesSection.getConfigurationSection(id);
            if (pageSection == null) {
                continue;
            }
            loadedPages.add(new ShopPage(
                    id.toLowerCase(Locale.ROOT),
                    pageSection.getInt("order", loadedPages.size() + 1),
                    pageSection.getString("title", id)
            ));
        }

        loadedPages.sort(Comparator.comparingInt(ShopPage::order).thenComparing(ShopPage::id));

        final Map<String, ShopPage> result = new LinkedHashMap<>();
        for (ShopPage page : loadedPages) {
            result.put(page.id(), page);
        }
        return result;
    }

    private Map<String, Substance> loadSubstances(final FileConfiguration config) {
        final ConfigurationSection substancesSection = config.getConfigurationSection("substances");
        if (substancesSection == null || pagesById.isEmpty()) {
            return Map.of();
        }

        final Map<String, Substance> result = new LinkedHashMap<>();
        final String fallbackPageId = pages.get(0).id();

        for (String id : substancesSection.getKeys(false)) {
            final ConfigurationSection section = substancesSection.getConfigurationSection(id);
            if (section == null) {
                continue;
            }

            final String normalizedId = id.toLowerCase(Locale.ROOT);
            final String configuredPageId = section.getString("page", fallbackPageId).toLowerCase(Locale.ROOT);
            final String pageId = pagesById.containsKey(configuredPageId) ? configuredPageId : fallbackPageId;
            final Material material = parseMaterialWithWarning(
                    "substances." + id + ".material",
                    section.getString("material", "PAPER"),
                    Material.PAPER
            );

            result.put(normalizedId, new Substance(
                    normalizedId,
                    pageId,
                    ConfigUtil.clampSlot(section.getInt("slot", 0), shopGui.size()),
                    material,
                    section.getInt("amount", 1),
                    section.getDouble("price", 0D),
                    section.getString("permission", ""),
                    section.getBoolean("hide-without-permission", false),
                    section.getInt("custom-model-data", 0),
                    section.getString("display-name", "<white>" + id + "</white>"),
                    section.getStringList("lore"),
                    Math.max(0, section.getInt("addiction.gain", addiction.defaultGain())),
                    Math.max(0, section.getInt("overdose.gain", overdose.defaultGain())),
                    loadEffects(section, "substances." + id + ".effects")
            ));
        }

        return result;
    }

    private Map<String, Remedy> loadRemedies(final FileConfiguration config) {
        final ConfigurationSection remediesSection = config.getConfigurationSection("remedies");
        if (remediesSection == null) {
            return Map.of();
        }

        final Map<String, Remedy> result = new LinkedHashMap<>();
        for (String id : remediesSection.getKeys(false)) {
            final ConfigurationSection section = remediesSection.getConfigurationSection(id);
            if (section == null) {
                continue;
            }

            final String normalizedId = id.toLowerCase(Locale.ROOT);
            final Material material = parseMaterialWithWarning(
                    "remedies." + id + ".material",
                    section.getString("material", "HONEY_BOTTLE"),
                    Material.HONEY_BOTTLE
            );

            result.put(normalizedId, new Remedy(
                    normalizedId,
                    ConfigUtil.clampSlot(section.getInt("slot", 0), remedyGui.size()),
                    material,
                    section.getInt("amount", 1),
                    section.getDouble("price", 0D),
                    section.getString("permission", ""),
                    section.getBoolean("hide-without-permission", false),
                    section.getInt("custom-model-data", 0),
                    section.getString("display-name", "<white>" + id + "</white>"),
                    section.getStringList("lore"),
                    section.getInt("overdose.decrease", 0),
                    section.getInt("addiction.decrease", 0),
                    loadEffects(section, "remedies." + id + ".effects")
            ));
        }

        return result;
    }

    private List<EffectSpec> loadEffects(final ConfigurationSection substanceSection, final String path) {
        return loadEffects(substanceSection, "effects", path);
    }

    private List<EffectSpec> loadEffects(final ConfigurationSection substanceSection, final String listKey, final String path) {
        if (substanceSection == null) {
            return List.of();
        }

        final List<Map<?, ?>> effectMaps = substanceSection.getMapList(listKey);
        final List<EffectSpec> effects = new ArrayList<>();

        for (int index = 0; index < effectMaps.size(); index++) {
            final Map<?, ?> map = effectMaps.get(index);
            final Object typeObject = map.containsKey("type") ? map.get("type") : "speed";
            final String rawType = String.valueOf(typeObject);
            final PotionEffectType type = ConfigUtil.parsePotionEffectType(rawType);
            if (type == null) {
                plugin.getMessages().send(plugin.getServer().getConsoleSender(), "config.invalid-effect", Map.of(
                        "effect", rawType,
                        "path", path + "." + index + ".type"
                ));
                continue;
            }

            final int durationSeconds = getInt(map, "duration-seconds", 30);
            final int level = getInt(map, "level", 1);
            effects.add(new EffectSpec(
                    type,
                    Math.max(1, durationSeconds) * 20,
                    Math.max(1, level),
                    getBoolean(map, "ambient", false),
                    getBoolean(map, "particles", true),
                    getBoolean(map, "icon", true)
            ));
        }

        return effects;
    }

    private int getInt(final Map<?, ?> map, final String key, final int fallback) {
        final Object value = map.get(key);
        if (value instanceof Number number) {
            return number.intValue();
        }
        if (value instanceof String stringValue) {
            try {
                return Integer.parseInt(stringValue);
            } catch (NumberFormatException ignored) {
                return fallback;
            }
        }
        return fallback;
    }

    private boolean getBoolean(final Map<?, ?> map, final String key, final boolean fallback) {
        final Object value = map.get(key);
        if (value instanceof Boolean booleanValue) {
            return booleanValue;
        }
        if (value instanceof String stringValue) {
            return Boolean.parseBoolean(stringValue);
        }
        return fallback;
    }

    private Material parseMaterialWithWarning(final String path, final String rawMaterial, final Material fallback) {
        final Material material = ConfigUtil.parseMaterial(rawMaterial, fallback);
        if (rawMaterial != null && !rawMaterial.isBlank() && Material.matchMaterial(rawMaterial.trim()) == null) {
            plugin.getMessages().send(plugin.getServer().getConsoleSender(), "config.invalid-material", Map.of(
                    "material", rawMaterial,
                    "path", path
            ));
        }
        return material;
    }

    public Optional<Substance> substance(final String id) {
        if (id == null) {
            return Optional.empty();
        }
        return Optional.ofNullable(substancesById.get(id.toLowerCase(Locale.ROOT)));
    }

    public Optional<Remedy> remedy(final String id) {
        if (id == null) {
            return Optional.empty();
        }
        return Optional.ofNullable(remediesById.get(id.toLowerCase(Locale.ROOT)));
    }

    public List<Substance> substancesForPage(final String pageId) {
        return substancesById.values().stream()
                .filter(substance -> substance.pageId().equalsIgnoreCase(pageId))
                .sorted(Comparator.comparingInt(Substance::slot).thenComparing(Substance::id))
                .toList();
    }

    public List<Remedy> remedies() {
        return remediesById.values().stream()
                .sorted(Comparator.comparingInt(Remedy::slot).thenComparing(Remedy::id))
                .toList();
    }

    public Optional<Integer> pageNumberById(final String id) {
        if (id == null) {
            return Optional.empty();
        }
        for (int index = 0; index < pages.size(); index++) {
            if (pages.get(index).id().equalsIgnoreCase(id)) {
                return Optional.of(index + 1);
            }
        }
        return Optional.empty();
    }

    public Map<String, String> basePlaceholders() {
        final Map<String, String> placeholders = new HashMap<>();
        placeholders.put("currency", currency.displayName());
        placeholders.put("plugin_name", pluginDisplayName);
        return placeholders;
    }

    public String pluginDisplayName() {
        return pluginDisplayName;
    }

    public String usePermission() {
        return usePermission;
    }

    public String adminPermission() {
        return adminPermission;
    }

    public int consumeCooldownSeconds() {
        return consumeCooldownSeconds;
    }

    public boolean dropOverflowItems() {
        return dropOverflowItems;
    }

    public boolean useSoundEnabled() {
        return useSoundEnabled;
    }

    public String useSoundName() {
        return useSoundName;
    }

    public float useSoundVolume() {
        return useSoundVolume;
    }

    public float useSoundPitch() {
        return useSoundPitch;
    }

    public CurrencySettings currency() {
        return currency;
    }

    public ShopGuiSettings shopGui() {
        return shopGui;
    }

    public RemedyGuiSettings remedyGui() {
        return remedyGui;
    }

    public PurchaseGuiSettings purchaseGui() {
        return purchaseGui;
    }

    public PurchaseGuiSettings remedyPurchaseGui() {
        return remedyPurchaseGui;
    }

    public AddictionSettings addiction() {
        return addiction;
    }

    public OverdoseSettings overdose() {
        return overdose;
    }

    public List<ShopPage> pages() {
        return pages;
    }

    public Map<String, ShopPage> pagesById() {
        return pagesById;
    }

    public Map<String, Substance> substancesById() {
        return substancesById;
    }

    public Map<String, Remedy> remediesById() {
        return remediesById;
    }
}

package ru.refactorum.drug.listener;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import ru.refactorum.drug.RefactorumDrugPlugin;
import ru.refactorum.drug.model.Remedy;
import ru.refactorum.drug.model.Substance;

import java.util.Optional;

public final class SubstanceUseListener implements Listener {

    private final RefactorumDrugPlugin plugin;

    public SubstanceUseListener(final RefactorumDrugPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(ignoreCancelled = true)
    public void onPlayerInteract(final PlayerInteractEvent event) {
        final Action action = event.getAction();
        if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) {
            return;
        }

        final EquipmentSlot hand = event.getHand();
        if (hand == null) {
            return;
        }

        final ItemStack item = event.getItem();
        final Optional<Substance> substance = plugin.getSubstanceService().fromItem(item);
        if (substance.isPresent()) {
            event.setCancelled(true);
            plugin.getSubstanceService().consume(event.getPlayer(), hand, item, substance.get());
            return;
        }

        final Optional<Remedy> remedy = plugin.getRemedyService().fromItem(item);
        if (remedy.isEmpty()) {
            return;
        }

        event.setCancelled(true);
        plugin.getRemedyService().use(event.getPlayer(), hand, item, remedy.get());
    }
}

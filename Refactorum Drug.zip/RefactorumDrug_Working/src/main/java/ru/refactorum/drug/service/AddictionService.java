package ru.refactorum.drug.service;

import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;
import ru.refactorum.drug.RefactorumDrugPlugin;
import ru.refactorum.drug.config.AddictionSettings;
import ru.refactorum.drug.model.AddictionProfile;
import ru.refactorum.drug.model.EffectSpec;
import ru.refactorum.drug.model.Substance;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

public final class AddictionService {

    private static final long MILLIS_PER_SECOND = 1000L;

    private final RefactorumDrugPlugin plugin;
    private final File dataFile;
    private final Map<UUID, AddictionProfile> profiles = new LinkedHashMap<>();
    private BukkitTask task;

    public AddictionService(final RefactorumDrugPlugin plugin) {
        this.plugin = Objects.requireNonNull(plugin, "plugin");
        this.dataFile = new File(plugin.getDataFolder(), "addictions.yml");
        loadAll();
        startTask();
    }

    public void shutdown() {
        if (task != null) {
            task.cancel();
            task = null;
        }
        saveAll();
    }

    public void recordUse(final Player player, final Substance substance) {
        final AddictionSettings settings = settings();
        if (!settings.enabled()) {
            return;
        }

        final int gain = Math.max(0, substance.addictionGain());
        if (gain <= 0) {
            return;
        }

        final long now = System.currentTimeMillis();
        final AddictionProfile profile = profile(player.getUniqueId());
        final int previousLevel = profile.level();
        profile.increase(gain, settings.maxLevel());
        profile.setLastUseMillis(now);
        profile.setLastDecayMillis(now);
        profile.setLastSubstanceId(substance.id());

        final Map<String, String> placeholders = placeholders(player, profile, gain);
        final String thresholdMessage = thresholdMessage(previousLevel, profile.level(), settings);
        if (thresholdMessage != null) {
            plugin.getMessages().send(player, thresholdMessage, placeholders);
        } else if (settings.notifyOnUse()) {
            plugin.getMessages().send(player, "addiction.increased", placeholders);
        }

        saveAll();
    }

    public void sendStatus(final CommandSender sender, final Player target, final boolean otherPlayer) {
        final AddictionSettings settings = settings();
        if (!settings.enabled()) {
            plugin.getMessages().send(sender, "addiction.disabled");
            return;
        }

        final AddictionProfile profile = profile(target.getUniqueId());
        plugin.getMessages().send(
                sender,
                otherPlayer ? "addiction.status-other" : "addiction.status-self",
                placeholders(target, profile, 0)
        );
    }

    public void reset(final Player target) {
        final AddictionProfile profile = profile(target.getUniqueId());
        profile.setLevel(0);
        profile.setLastUseMillis(0L);
        profile.setLastDecayMillis(0L);
        profile.setLastWithdrawalMillis(0L);
        profile.setLastWithdrawalMessageMillis(0L);
        profile.setLastSubstanceId("");
        saveAll();
    }

    public int setLevel(final Player target, final int level) {
        final AddictionSettings settings = settings();
        final AddictionProfile profile = profile(target.getUniqueId());
        final int updatedLevel = Math.max(0, Math.min(settings.maxLevel(), level));
        final long now = System.currentTimeMillis();
        profile.setLevel(updatedLevel);
        if (updatedLevel <= 0) {
            profile.setLastUseMillis(0L);
            profile.setLastDecayMillis(0L);
            profile.setLastWithdrawalMillis(0L);
            profile.setLastWithdrawalMessageMillis(0L);
            profile.setLastSubstanceId("");
        } else {
            if (profile.lastUseMillis() <= 0L) {
                profile.setLastUseMillis(now);
            }
            profile.setLastDecayMillis(now);
        }
        saveAll();
        return updatedLevel;
    }

    public int decrease(final Player target, final int amount) {
        final AddictionProfile profile = profile(target.getUniqueId());
        final int previousLevel = profile.level();
        profile.decrease(amount);
        if (profile.level() <= 0) {
            profile.setLastUseMillis(0L);
            profile.setLastDecayMillis(0L);
            profile.setLastWithdrawalMillis(0L);
            profile.setLastWithdrawalMessageMillis(0L);
            profile.setLastSubstanceId("");
        }
        saveAll();
        return Math.max(0, previousLevel - profile.level());
    }

    public int level(final UUID uniqueId) {
        return profile(uniqueId).level();
    }

    private void startTask() {
        final AddictionSettings settings = settings();
        if (!settings.enabled()) {
            return;
        }

        final long intervalTicks = Math.max(20L, settings.checkIntervalSeconds() * 20L);
        this.task = plugin.getServer().getScheduler().runTaskTimer(plugin, this::tickOnlinePlayers, intervalTicks, intervalTicks);
    }

    private void tickOnlinePlayers() {
        final AddictionSettings settings = settings();
        if (!settings.enabled()) {
            return;
        }

        final long now = System.currentTimeMillis();
        boolean changed = false;
        for (Player player : plugin.getServer().getOnlinePlayers()) {
            final AddictionProfile profile = profiles.get(player.getUniqueId());
            if (profile == null || profile.level() <= 0) {
                continue;
            }

            changed |= processDecay(player, profile, settings, now);
            changed |= processWithdrawal(player, profile, settings, now);
        }

        if (changed) {
            saveAll();
        }
    }

    private boolean processDecay(
            final Player player,
            final AddictionProfile profile,
            final AddictionSettings settings,
            final long now
    ) {
        if (!settings.decayEnabled() || profile.lastUseMillis() <= 0L) {
            return false;
        }

        if (now - profile.lastUseMillis() < secondsToMillis(settings.decayStartAfterSeconds())) {
            return false;
        }

        if (now - profile.lastDecayMillis() < secondsToMillis(settings.decayIntervalSeconds())) {
            return false;
        }

        final int previousLevel = profile.level();
        profile.decrease(settings.decayAmount());
        profile.setLastDecayMillis(now);

        if (previousLevel > 0 && profile.level() == 0) {
            plugin.getMessages().send(player, "addiction.recovered", placeholders(player, profile, 0));
        }

        return previousLevel != profile.level();
    }

    private boolean processWithdrawal(
            final Player player,
            final AddictionProfile profile,
            final AddictionSettings settings,
            final long now
    ) {
        if (!settings.withdrawalEnabled() || profile.lastUseMillis() <= 0L) {
            return false;
        }

        if (profile.level() < settings.withdrawalMinLevel()) {
            return false;
        }

        if (now - profile.lastUseMillis() < secondsToMillis(settings.withdrawalStartAfterSeconds())) {
            return false;
        }

        if (now - profile.lastWithdrawalMillis() < secondsToMillis(settings.withdrawalIntervalSeconds())) {
            return false;
        }

        for (EffectSpec effect : settings.withdrawalEffects()) {
            player.addPotionEffect(effect.toPotionEffect(), true);
        }

        profile.setLastWithdrawalMillis(now);
        boolean changed = true;
        if (now - profile.lastWithdrawalMessageMillis() >= secondsToMillis(settings.withdrawalMessageCooldownSeconds())) {
            profile.setLastWithdrawalMessageMillis(now);
            plugin.getMessages().send(player, "addiction.withdrawal", placeholders(player, profile, 0));
            changed = true;
        }

        return changed;
    }

    private String thresholdMessage(final int previousLevel, final int currentLevel, final AddictionSettings settings) {
        if (previousLevel < settings.criticalLevel() && currentLevel >= settings.criticalLevel()) {
            return "addiction.threshold-critical";
        }
        if (previousLevel < settings.strongLevel() && currentLevel >= settings.strongLevel()) {
            return "addiction.threshold-strong";
        }
        if (previousLevel < settings.mildLevel() && currentLevel >= settings.mildLevel()) {
            return "addiction.threshold-mild";
        }
        return null;
    }

    private AddictionProfile profile(final UUID uniqueId) {
        return profiles.computeIfAbsent(uniqueId, AddictionProfile::empty);
    }

    private Map<String, String> placeholders(final Player player, final AddictionProfile profile, final int gain) {
        final AddictionSettings settings = settings();
        final Map<String, String> placeholders = new HashMap<>(plugin.getShopConfig().basePlaceholders());
        final int level = Math.max(0, Math.min(settings.maxLevel(), profile.level()));
        final int percent = (int) Math.round(level * 100.0D / settings.maxLevel());
        placeholders.put("player", player.getName());
        placeholders.put("level", String.valueOf(level));
        placeholders.put("max_level", String.valueOf(settings.maxLevel()));
        placeholders.put("percent", String.valueOf(percent));
        placeholders.put("gain", String.valueOf(Math.max(0, gain)));
        placeholders.put("stage", stageName(level, settings));
        placeholders.put("last_substance", profile.lastSubstanceId().isBlank() ? "-" : profile.lastSubstanceId());
        placeholders.put("time_since_last_use", formatSince(profile.lastUseMillis()));
        return placeholders;
    }

    private String stageName(final int level, final AddictionSettings settings) {
        if (level <= 0) {
            return plugin.getMessages().raw("addiction.stage.clean", "<green>нет зависимости</green>");
        }
        if (level >= settings.criticalLevel()) {
            return plugin.getMessages().raw("addiction.stage.critical", "<dark_red>критическая</dark_red>");
        }
        if (level >= settings.strongLevel()) {
            return plugin.getMessages().raw("addiction.stage.strong", "<red>сильная</red>");
        }
        if (level >= settings.mildLevel()) {
            return plugin.getMessages().raw("addiction.stage.mild", "<yellow>заметная</yellow>");
        }
        return plugin.getMessages().raw("addiction.stage.low", "<gray>низкая</gray>");
    }

    private String formatSince(final long timestampMillis) {
        if (timestampMillis <= 0L) {
            return "-";
        }
        final long seconds = Math.max(0L, (System.currentTimeMillis() - timestampMillis) / MILLIS_PER_SECOND);
        if (seconds < 60L) {
            return seconds + " сек.";
        }
        final long minutes = seconds / 60L;
        final long remainingSeconds = seconds % 60L;
        if (minutes < 60L) {
            return minutes + " мин. " + remainingSeconds + " сек.";
        }
        final long hours = minutes / 60L;
        final long remainingMinutes = minutes % 60L;
        return hours + " ч. " + remainingMinutes + " мин.";
    }

    private long secondsToMillis(final int seconds) {
        return Math.max(1, seconds) * MILLIS_PER_SECOND;
    }

    private AddictionSettings settings() {
        return plugin.getShopConfig().addiction();
    }

    private void loadAll() {
        if (!dataFile.exists()) {
            return;
        }

        final YamlConfiguration data = YamlConfiguration.loadConfiguration(dataFile);
        final ConfigurationSection playersSection = data.getConfigurationSection("players");
        if (playersSection == null) {
            return;
        }

        for (String rawUniqueId : playersSection.getKeys(false)) {
            final UUID uniqueId;
            try {
                uniqueId = UUID.fromString(rawUniqueId);
            } catch (IllegalArgumentException ignored) {
                plugin.getLogger().warning("Invalid UUID in addictions.yml: " + rawUniqueId);
                continue;
            }

            final String path = "players." + rawUniqueId;
            profiles.put(uniqueId, new AddictionProfile(
                    uniqueId,
                    data.getInt(path + ".level", 0),
                    data.getLong(path + ".last-use", 0L),
                    data.getLong(path + ".last-decay", 0L),
                    data.getLong(path + ".last-withdrawal", 0L),
                    data.getLong(path + ".last-withdrawal-message", 0L),
                    data.getString(path + ".last-substance", "")
            ));
        }
    }

    private void saveAll() {
        final YamlConfiguration data = new YamlConfiguration();
        for (AddictionProfile profile : profiles.values()) {
            if (profile.level() <= 0 && profile.lastUseMillis() <= 0L) {
                continue;
            }

            final String path = "players." + profile.uniqueId();
            data.set(path + ".level", Math.max(0, Math.min(settings().maxLevel(), profile.level())));
            data.set(path + ".last-use", profile.lastUseMillis());
            data.set(path + ".last-decay", profile.lastDecayMillis());
            data.set(path + ".last-withdrawal", profile.lastWithdrawalMillis());
            data.set(path + ".last-withdrawal-message", profile.lastWithdrawalMessageMillis());
            data.set(path + ".last-substance", profile.lastSubstanceId());
        }

        try {
            data.save(dataFile);
        } catch (IOException exception) {
            plugin.getLogger().severe("Could not save addictions.yml: " + exception.getMessage());
        }
    }
}

package ru.refactorum.drug.service;

import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import ru.refactorum.drug.RefactorumDrugPlugin;
import ru.refactorum.drug.config.CurrencySettings;
import ru.refactorum.drug.service.economy.EconomyBridge;
import ru.refactorum.drug.service.economy.VaultEconomyBridge;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;
import java.util.Objects;

public final class CurrencyService {

    private final RefactorumDrugPlugin plugin;
    private final DecimalFormat decimalFormat;
    private EconomyBridge economy;

    public CurrencyService(final RefactorumDrugPlugin plugin) {
        this.plugin = Objects.requireNonNull(plugin, "plugin");
        this.decimalFormat = createFormat(plugin.getShopConfig().currency().amountFormat());
        setupEconomy();
    }

    public boolean ready() {
        return !plugin.getShopConfig().currency().vaultMode() || economy != null;
    }

    public double balance(final Player player) {
        final CurrencySettings settings = plugin.getShopConfig().currency();
        if (settings.vaultMode()) {
            return economy == null ? 0D : economy.balance(player);
        }
        return countItems(player.getInventory());
    }

    public boolean has(final Player player, final double price) {
        if (price <= 0D) {
            return true;
        }

        final CurrencySettings settings = plugin.getShopConfig().currency();
        if (settings.vaultMode()) {
            return economy != null && economy.has(player, price);
        }
        return countItems(player.getInventory()) >= itemPrice(price);
    }

    public boolean withdraw(final Player player, final double price) {
        if (price <= 0D) {
            return true;
        }

        final CurrencySettings settings = plugin.getShopConfig().currency();
        if (settings.vaultMode()) {
            return economy != null && economy.withdraw(player, price);
        }

        withdrawItems(player.getInventory(), itemPrice(price));
        return true;
    }

    public String format(final double amount) {
        final CurrencySettings settings = plugin.getShopConfig().currency();
        if (settings.vaultMode() && settings.useVaultFormat() && economy != null) {
            return economy.format(amount);
        }
        return decimalFormat.format(amount);
    }

    private DecimalFormat createFormat(final String pattern) {
        try {
            return new DecimalFormat(pattern == null || pattern.isBlank() ? "#,##0.##" : pattern, DecimalFormatSymbols.getInstance(Locale.US));
        } catch (IllegalArgumentException ignored) {
            return new DecimalFormat("#,##0.##", DecimalFormatSymbols.getInstance(Locale.US));
        }
    }

    private void setupEconomy() {
        if (!plugin.getShopConfig().currency().vaultMode()) {
            return;
        }

        if (plugin.getServer().getPluginManager().getPlugin("Vault") == null) {
            plugin.getLogger().warning("Vault mode is enabled, but Vault was not found");
            return;
        }

        this.economy = VaultEconomyBridge.create(plugin);
        if (economy == null) {
            plugin.getLogger().warning("Vault mode is enabled, but no economy provider was found");
        }
    }

    private int countItems(final PlayerInventory inventory) {
        int amount = 0;
        for (ItemStack item : inventory.getStorageContents()) {
            if (isCurrencyItem(item)) {
                amount += item.getAmount();
            }
        }
        return amount;
    }

    private void withdrawItems(final PlayerInventory inventory, final int price) {
        int remaining = price;
        final ItemStack[] storage = inventory.getStorageContents();

        for (int slot = 0; slot < storage.length; slot++) {
            final ItemStack item = storage[slot];
            if (!isCurrencyItem(item)) {
                continue;
            }

            final int take = Math.min(remaining, item.getAmount());
            item.setAmount(item.getAmount() - take);
            if (item.getAmount() <= 0) {
                storage[slot] = null;
            }

            remaining -= take;
            if (remaining <= 0) {
                break;
            }
        }

        inventory.setStorageContents(storage);
    }

    private boolean isCurrencyItem(final ItemStack item) {
        if (item == null || item.getType().isAir()) {
            return false;
        }

        final CurrencySettings settings = plugin.getShopConfig().currency();
        if (item.getType() != settings.itemMaterial()) {
            return false;
        }

        if (!settings.itemRequireCustomModelData()) {
            return true;
        }

        final ItemMeta meta = item.getItemMeta();
        return meta != null && meta.hasCustomModelData() && meta.getCustomModelData() == settings.itemCustomModelData();
    }

    private int itemPrice(final double price) {
        return (int) Math.ceil(Math.max(0D, price));
    }
}

package ru.refactorum.drug.config;

import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import ru.refactorum.drug.service.MessageService;
import ru.refactorum.drug.util.ConfigUtil;

import java.util.Collections;
import java.util.List;
import java.util.Map;

public final class ConfigItem {

    private final Material material;
    private final int amount;
    private final String displayName;
    private final List<String> lore;
    private final int customModelData;
    private final boolean hideAttributes;

    public ConfigItem(
            final Material material,
            final int amount,
            final String displayName,
            final List<String> lore,
            final int customModelData,
            final boolean hideAttributes
    ) {
        this.material = material;
        this.amount = Math.max(1, Math.min(64, amount));
        this.displayName = displayName == null ? "" : displayName;
        this.lore = lore == null ? Collections.emptyList() : List.copyOf(lore);
        this.customModelData = customModelData;
        this.hideAttributes = hideAttributes;
    }

    public static ConfigItem fromSection(final ConfigurationSection section, final Material fallbackMaterial) {
        if (section == null) {
            return new ConfigItem(fallbackMaterial, 1, "", Collections.emptyList(), 0, true);
        }

        return new ConfigItem(
                ConfigUtil.parseMaterial(section.getString("material"), fallbackMaterial),
                section.getInt("amount", 1),
                section.getString("display-name", ""),
                section.getStringList("lore"),
                section.getInt("custom-model-data", 0),
                section.getBoolean("hide-attributes", true)
        );
    }

    public ItemStack build(final MessageService messages, final Map<String, String> placeholders) {
        final ItemStack item = new ItemStack(material, amount);
        final ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return item;
        }

        if (!displayName.isBlank()) {
            meta.displayName(messages.deserialize(displayName, placeholders));
        }

        if (!lore.isEmpty()) {
            final List<Component> formattedLore = messages.deserializeList(lore, placeholders);
            meta.lore(formattedLore);
        }

        if (customModelData > 0) {
            meta.setCustomModelData(customModelData);
        }

        if (hideAttributes) {
            meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
        }

        item.setItemMeta(meta);
        return item;
    }

    public Material material() {
        return material;
    }

    public int amount() {
        return amount;
    }

    public String displayName() {
        return displayName;
    }

    public List<String> lore() {
        return lore;
    }

    public int customModelData() {
        return customModelData;
    }
}

package ru.refactorum.drug.service.economy;

import org.bukkit.entity.Player;

public interface EconomyBridge {

    double balance(Player player);

    boolean has(Player player, double amount);

    boolean withdraw(Player player, double amount);

    String format(double amount);
}

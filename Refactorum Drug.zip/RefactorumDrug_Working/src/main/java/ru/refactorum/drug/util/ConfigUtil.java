package ru.refactorum.drug.util;

import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.potion.PotionEffectType;

import java.util.Locale;

public final class ConfigUtil {

    private ConfigUtil() {
    }

    public static int clampInventorySize(final int configuredSize, final int fallbackSize) {
        if (configuredSize >= 9 && configuredSize <= 54 && configuredSize % 9 == 0) {
            return configuredSize;
        }
        return fallbackSize;
    }

    public static int clampSlot(final int slot, final int inventorySize) {
        if (slot < 0) {
            return 0;
        }
        if (slot >= inventorySize) {
            return inventorySize - 1;
        }
        return slot;
    }

    public static Material parseMaterial(final String rawMaterial, final Material fallback) {
        if (rawMaterial == null || rawMaterial.isBlank()) {
            return fallback;
        }

        final Material material = Material.matchMaterial(rawMaterial.trim());
        return material == null ? fallback : material;
    }

    public static PotionEffectType parsePotionEffectType(final String rawEffect) {
        if (rawEffect == null || rawEffect.isBlank()) {
            return null;
        }

        String keyText = rawEffect.trim()
                .toLowerCase(Locale.ROOT)
                .replace(' ', '_');

        final NamespacedKey key;
        if (keyText.contains(":")) {
            key = NamespacedKey.fromString(keyText);
        } else {
            key = NamespacedKey.minecraft(keyText);
        }

        if (key == null) {
            return null;
        }
        return Registry.EFFECT.get(key);
    }

    public static ConfigurationSection requireSection(final ConfigurationSection parent, final String path) {
        final ConfigurationSection section = parent.getConfigurationSection(path);
        if (section == null) {
            return parent.createSection(path);
        }
        return section;
    }
}

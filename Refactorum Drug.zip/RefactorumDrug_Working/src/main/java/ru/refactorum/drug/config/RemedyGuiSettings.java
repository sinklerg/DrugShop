package ru.refactorum.drug.config;

import java.util.List;

public final class RemedyGuiSettings {

    private final int size;
    private final String title;
    private final boolean fillEnabled;
    private final ConfigItem fillItem;
    private final ButtonConfig backButton;
    private final ButtonConfig closeButton;
    private final List<String> priceLore;

    public RemedyGuiSettings(
            final int size,
            final String title,
            final boolean fillEnabled,
            final ConfigItem fillItem,
            final ButtonConfig backButton,
            final ButtonConfig closeButton,
            final List<String> priceLore
    ) {
        this.size = size;
        this.title = title;
        this.fillEnabled = fillEnabled;
        this.fillItem = fillItem;
        this.backButton = backButton;
        this.closeButton = closeButton;
        this.priceLore = List.copyOf(priceLore);
    }

    public int size() {
        return size;
    }

    public String title() {
        return title;
    }

    public boolean fillEnabled() {
        return fillEnabled;
    }

    public ConfigItem fillItem() {
        return fillItem;
    }

    public ButtonConfig backButton() {
        return backButton;
    }

    public ButtonConfig closeButton() {
        return closeButton;
    }

    public List<String> priceLore() {
        return priceLore;
    }
}

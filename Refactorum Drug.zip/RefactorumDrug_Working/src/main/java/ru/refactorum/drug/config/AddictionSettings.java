package ru.refactorum.drug.config;

import ru.refactorum.drug.model.EffectSpec;

import java.util.Collections;
import java.util.List;

public final class AddictionSettings {

    private final boolean enabled;
    private final int maxLevel;
    private final int defaultGain;
    private final int mildLevel;
    private final int strongLevel;
    private final int criticalLevel;
    private final int checkIntervalSeconds;
    private final boolean notifyOnUse;
    private final boolean withdrawalEnabled;
    private final int withdrawalMinLevel;
    private final int withdrawalStartAfterSeconds;
    private final int withdrawalIntervalSeconds;
    private final int withdrawalMessageCooldownSeconds;
    private final List<EffectSpec> withdrawalEffects;
    private final boolean decayEnabled;
    private final int decayStartAfterSeconds;
    private final int decayIntervalSeconds;
    private final int decayAmount;

    public AddictionSettings(
            final boolean enabled,
            final int maxLevel,
            final int defaultGain,
            final int mildLevel,
            final int strongLevel,
            final int criticalLevel,
            final int checkIntervalSeconds,
            final boolean notifyOnUse,
            final boolean withdrawalEnabled,
            final int withdrawalMinLevel,
            final int withdrawalStartAfterSeconds,
            final int withdrawalIntervalSeconds,
            final int withdrawalMessageCooldownSeconds,
            final List<EffectSpec> withdrawalEffects,
            final boolean decayEnabled,
            final int decayStartAfterSeconds,
            final int decayIntervalSeconds,
            final int decayAmount
    ) {
        this.enabled = enabled;
        this.maxLevel = Math.max(1, maxLevel);
        this.defaultGain = Math.max(0, defaultGain);
        this.mildLevel = clampLevel(mildLevel, this.maxLevel);
        this.strongLevel = clampLevel(strongLevel, this.maxLevel);
        this.criticalLevel = clampLevel(criticalLevel, this.maxLevel);
        this.checkIntervalSeconds = Math.max(1, checkIntervalSeconds);
        this.notifyOnUse = notifyOnUse;
        this.withdrawalEnabled = withdrawalEnabled;
        this.withdrawalMinLevel = clampLevel(withdrawalMinLevel, this.maxLevel);
        this.withdrawalStartAfterSeconds = Math.max(1, withdrawalStartAfterSeconds);
        this.withdrawalIntervalSeconds = Math.max(1, withdrawalIntervalSeconds);
        this.withdrawalMessageCooldownSeconds = Math.max(1, withdrawalMessageCooldownSeconds);
        this.withdrawalEffects = withdrawalEffects == null ? Collections.emptyList() : List.copyOf(withdrawalEffects);
        this.decayEnabled = decayEnabled;
        this.decayStartAfterSeconds = Math.max(1, decayStartAfterSeconds);
        this.decayIntervalSeconds = Math.max(1, decayIntervalSeconds);
        this.decayAmount = Math.max(1, decayAmount);
    }

    private int clampLevel(final int value, final int maxLevel) {
        return Math.max(0, Math.min(maxLevel, value));
    }

    public boolean enabled() {
        return enabled;
    }

    public int maxLevel() {
        return maxLevel;
    }

    public int defaultGain() {
        return defaultGain;
    }

    public int mildLevel() {
        return mildLevel;
    }

    public int strongLevel() {
        return strongLevel;
    }

    public int criticalLevel() {
        return criticalLevel;
    }

    public int checkIntervalSeconds() {
        return checkIntervalSeconds;
    }

    public boolean notifyOnUse() {
        return notifyOnUse;
    }

    public boolean withdrawalEnabled() {
        return withdrawalEnabled;
    }

    public int withdrawalMinLevel() {
        return withdrawalMinLevel;
    }

    public int withdrawalStartAfterSeconds() {
        return withdrawalStartAfterSeconds;
    }

    public int withdrawalIntervalSeconds() {
        return withdrawalIntervalSeconds;
    }

    public int withdrawalMessageCooldownSeconds() {
        return withdrawalMessageCooldownSeconds;
    }

    public List<EffectSpec> withdrawalEffects() {
        return withdrawalEffects;
    }

    public boolean decayEnabled() {
        return decayEnabled;
    }

    public int decayStartAfterSeconds() {
        return decayStartAfterSeconds;
    }

    public int decayIntervalSeconds() {
        return decayIntervalSeconds;
    }

    public int decayAmount() {
        return decayAmount;
    }
}

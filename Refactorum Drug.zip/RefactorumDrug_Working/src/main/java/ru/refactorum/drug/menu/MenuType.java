package ru.refactorum.drug.menu;

public enum MenuType {
    SHOP,
    PURCHASE,
    REMEDIES,
    REMEDY_PURCHASE
}

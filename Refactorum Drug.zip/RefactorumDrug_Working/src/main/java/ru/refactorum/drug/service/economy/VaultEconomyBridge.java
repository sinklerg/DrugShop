package ru.refactorum.drug.service.economy;

import net.milkbowl.vault.economy.Economy;
import net.milkbowl.vault.economy.EconomyResponse;
import org.bukkit.entity.Player;
import org.bukkit.plugin.RegisteredServiceProvider;
import ru.refactorum.drug.RefactorumDrugPlugin;

import java.util.Objects;

public final class VaultEconomyBridge implements EconomyBridge {

    private final Economy economy;

    private VaultEconomyBridge(final Economy economy) {
        this.economy = Objects.requireNonNull(economy, "economy");
    }

    public static VaultEconomyBridge create(final RefactorumDrugPlugin plugin) {
        final RegisteredServiceProvider<Economy> registration = plugin.getServer().getServicesManager().getRegistration(Economy.class);
        if (registration == null) {
            return null;
        }
        return new VaultEconomyBridge(registration.getProvider());
    }

    @Override
    public double balance(final Player player) {
        return Math.max(0D, economy.getBalance(player));
    }

    @Override
    public boolean has(final Player player, final double amount) {
        return economy.has(player, amount);
    }

    @Override
    public boolean withdraw(final Player player, final double amount) {
        final EconomyResponse response = economy.withdrawPlayer(player, amount);
        return response.transactionSuccess();
    }

    @Override
    public String format(final double amount) {
        return economy.format(amount);
    }
}

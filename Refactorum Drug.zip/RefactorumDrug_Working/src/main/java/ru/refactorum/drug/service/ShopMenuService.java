package ru.refactorum.drug.service;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import ru.refactorum.drug.RefactorumDrugPlugin;
import ru.refactorum.drug.config.ButtonConfig;
import ru.refactorum.drug.config.PurchaseGuiSettings;
import ru.refactorum.drug.config.RemedyGuiSettings;
import ru.refactorum.drug.config.ShopConfig;
import ru.refactorum.drug.config.ShopGuiSettings;
import ru.refactorum.drug.menu.DrugShopHolder;
import ru.refactorum.drug.menu.MenuType;
import ru.refactorum.drug.model.Remedy;
import ru.refactorum.drug.model.ShopPage;
import ru.refactorum.drug.model.Substance;
import ru.refactorum.drug.util.ConfigUtil;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

public final class ShopMenuService {

    private final RefactorumDrugPlugin plugin;

    public ShopMenuService(final RefactorumDrugPlugin plugin) {
        this.plugin = Objects.requireNonNull(plugin, "plugin");
    }

    public void openShop(final Player player, final int pageNumber) {
        final ShopConfig config = plugin.getShopConfig();
        final List<ShopPage> pages = config.pages();
        if (pages.isEmpty()) {
            plugin.getMessages().send(player, "shop.no-pages");
            return;
        }

        if (pageNumber < 1 || pageNumber > pages.size()) {
            plugin.getMessages().send(player, "shop.invalid-page");
            return;
        }

        final int pageIndex = pageNumber - 1;
        final ShopPage page = pages.get(pageIndex);
        final ShopGuiSettings gui = config.shopGui();
        final Map<String, String> placeholders = pagePlaceholders(page, pageIndex);
        final Component title = plugin.getMessages().deserialize(gui.title(), placeholders);

        final DrugShopHolder holder = new DrugShopHolder(MenuType.SHOP, pageIndex, null);
        final Inventory inventory = Bukkit.createInventory(holder, gui.size(), title);
        holder.setInventory(inventory);

        applyFill(inventory, gui.fillEnabled(), gui.fillItem().build(plugin.getMessages(), placeholders));
        placeSubstances(player, inventory, page);
        placeShopButtons(inventory, pageIndex, placeholders);

        player.openInventory(inventory);

        final boolean hasVisibleSubstances = plugin.getShopConfig().substancesForPage(page.id()).stream()
                .anyMatch(substance -> !substance.hideWithoutPermission()
                        || !substance.hasPermissionRestriction()
                        || player.hasPermission(substance.permission()));
        if (!hasVisibleSubstances) {
            plugin.getMessages().send(player, "shop.no-substances");
        }
    }

    public void openRemedies(final Player player, final int returnPageIndex) {
        final RemedyGuiSettings gui = plugin.getShopConfig().remedyGui();
        final Map<String, String> placeholders = new HashMap<>(plugin.getShopConfig().basePlaceholders());
        placeholders.put("return_page", String.valueOf(returnPageIndex + 1));
        final Component title = plugin.getMessages().deserialize(gui.title(), placeholders);

        final DrugShopHolder holder = new DrugShopHolder(MenuType.REMEDIES, returnPageIndex, null);
        final Inventory inventory = Bukkit.createInventory(holder, gui.size(), title);
        holder.setInventory(inventory);

        applyFill(inventory, gui.fillEnabled(), gui.fillItem().build(plugin.getMessages(), placeholders));
        placeRemedies(player, inventory);
        placeButton(inventory, gui.backButton(), "back", placeholders);
        placeButton(inventory, gui.closeButton(), "close", placeholders);

        player.openInventory(inventory);

        final boolean hasVisibleRemedies = plugin.getShopConfig().remedies().stream()
                .anyMatch(remedy -> !remedy.hideWithoutPermission()
                        || !remedy.hasPermissionRestriction()
                        || player.hasPermission(remedy.permission()));
        if (!hasVisibleRemedies) {
            plugin.getMessages().send(player, "remedy.no-remedies");
        }
    }

    public void openPurchase(final Player player, final Substance substance, final int returnPageIndex) {
        final PurchaseGuiSettings gui = plugin.getShopConfig().purchaseGui();
        final Map<String, String> placeholders = plugin.getSubstanceService().placeholders(substance);
        final Component title = plugin.getMessages().deserialize(gui.title(), placeholders);

        final DrugShopHolder holder = new DrugShopHolder(MenuType.PURCHASE, returnPageIndex, substance.id());
        final Inventory inventory = Bukkit.createInventory(holder, gui.size(), title);
        holder.setInventory(inventory);

        applyFill(inventory, gui.fillEnabled(), gui.fillItem().build(plugin.getMessages(), placeholders));
        inventory.setItem(gui.previewSlot(), plugin.getSubstanceService().createSubstanceItem(substance));
        placeButton(inventory, gui.confirmButton(), "confirm", placeholders);
        placeButton(inventory, gui.backButton(), "back", placeholders);

        player.openInventory(inventory);
    }

    public void openRemedyPurchase(final Player player, final Remedy remedy, final int returnPageIndex) {
        final PurchaseGuiSettings gui = plugin.getShopConfig().remedyPurchaseGui();
        final Map<String, String> placeholders = plugin.getRemedyService().placeholders(remedy);
        final Component title = plugin.getMessages().deserialize(gui.title(), placeholders);

        final DrugShopHolder holder = new DrugShopHolder(MenuType.REMEDY_PURCHASE, returnPageIndex, remedy.id());
        final Inventory inventory = Bukkit.createInventory(holder, gui.size(), title);
        holder.setInventory(inventory);

        applyFill(inventory, gui.fillEnabled(), gui.fillItem().build(plugin.getMessages(), placeholders));
        inventory.setItem(gui.previewSlot(), plugin.getRemedyService().createRemedyItem(remedy));
        placeButton(inventory, gui.confirmButton(), "confirm", placeholders);
        placeButton(inventory, gui.backButton(), "back", placeholders);

        player.openInventory(inventory);
    }

    public Optional<String> readAction(final ItemStack item) {
        if (item == null || item.getType().isAir()) {
            return Optional.empty();
        }

        final ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return Optional.empty();
        }

        return Optional.ofNullable(meta.getPersistentDataContainer().get(plugin.actionKey(), PersistentDataType.STRING));
    }

    private void placeSubstances(final Player player, final Inventory inventory, final ShopPage page) {
        for (Substance substance : plugin.getShopConfig().substancesForPage(page.id())) {
            if (substance.hideWithoutPermission()
                    && substance.hasPermissionRestriction()
                    && !player.hasPermission(substance.permission())) {
                continue;
            }

            final ItemStack item = createShopItem(substance);
            tagAction(item, "substance:" + substance.id());
            inventory.setItem(ConfigUtil.clampSlot(substance.slot(), inventory.getSize()), item);
        }
    }

    private void placeRemedies(final Player player, final Inventory inventory) {
        for (Remedy remedy : plugin.getShopConfig().remedies()) {
            if (remedy.hideWithoutPermission()
                    && remedy.hasPermissionRestriction()
                    && !player.hasPermission(remedy.permission())) {
                continue;
            }

            final ItemStack item = createRemedyShopItem(remedy);
            tagAction(item, "remedy:" + remedy.id());
            inventory.setItem(ConfigUtil.clampSlot(remedy.slot(), inventory.getSize()), item);
        }
    }

    private ItemStack createShopItem(final Substance substance) {
        final ItemStack item = plugin.getSubstanceService().createSubstanceItem(substance);
        final ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return item;
        }

        final Map<String, String> placeholders = plugin.getSubstanceService().placeholders(substance);
        final List<Component> lore = meta.lore() == null ? new ArrayList<>() : new ArrayList<>(meta.lore());
        lore.addAll(plugin.getMessages().deserializeList(plugin.getShopConfig().shopGui().priceLore(), placeholders));
        meta.lore(lore);
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack createRemedyShopItem(final Remedy remedy) {
        final ItemStack item = plugin.getRemedyService().createRemedyItem(remedy);
        final ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return item;
        }

        final Map<String, String> placeholders = plugin.getRemedyService().placeholders(remedy);
        final List<Component> lore = meta.lore() == null ? new ArrayList<>() : new ArrayList<>(meta.lore());
        lore.addAll(plugin.getMessages().deserializeList(plugin.getShopConfig().remedyGui().priceLore(), placeholders));
        meta.lore(lore);
        item.setItemMeta(meta);
        return item;
    }

    private void placeShopButtons(final Inventory inventory, final int pageIndex, final Map<String, String> placeholders) {
        final List<ShopPage> pages = plugin.getShopConfig().pages();
        final ShopGuiSettings gui = plugin.getShopConfig().shopGui();

        final Map<String, String> previousPlaceholders = new HashMap<>(placeholders);
        previousPlaceholders.put("target_page", String.valueOf(pageIndex));
        if (pageIndex > 0) {
            placeButton(inventory, gui.previousButton(), "previous", previousPlaceholders);
        }

        final Map<String, String> remediesPlaceholders = new HashMap<>(placeholders);
        remediesPlaceholders.put("target_page", String.valueOf(pageIndex + 1));
        placeButton(inventory, gui.remediesButton(), "remedies", remediesPlaceholders);
        placeButton(inventory, gui.closeButton(), "close", placeholders);

        final Map<String, String> nextPlaceholders = new HashMap<>(placeholders);
        nextPlaceholders.put("target_page", String.valueOf(pageIndex + 2));
        if (pageIndex < pages.size() - 1) {
            placeButton(inventory, gui.nextButton(), "next", nextPlaceholders);
        }
    }

    private void placeButton(
            final Inventory inventory,
            final ButtonConfig button,
            final String action,
            final Map<String, String> placeholders
    ) {
        final int slot = ConfigUtil.clampSlot(button.slot(), inventory.getSize());
        final ItemStack item = button.item().build(plugin.getMessages(), placeholders);
        tagAction(item, action);
        inventory.setItem(slot, item);
    }

    private void applyFill(final Inventory inventory, final boolean enabled, final ItemStack fillItem) {
        if (!enabled || fillItem == null || fillItem.getType() == Material.AIR) {
            return;
        }

        for (int slot = 0; slot < inventory.getSize(); slot++) {
            final ItemStack current = inventory.getItem(slot);
            if (current == null || current.getType().isAir()) {
                inventory.setItem(slot, fillItem.clone());
            }
        }
    }

    private void tagAction(final ItemStack item, final String action) {
        final ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return;
        }
        meta.getPersistentDataContainer().set(plugin.actionKey(), PersistentDataType.STRING, action);
        item.setItemMeta(meta);
    }

    private Map<String, String> pagePlaceholders(final ShopPage page, final int pageIndex) {
        final Map<String, String> placeholders = new HashMap<>(plugin.getShopConfig().basePlaceholders());
        placeholders.put("page", String.valueOf(pageIndex + 1));
        placeholders.put("pages", String.valueOf(plugin.getShopConfig().pages().size()));
        placeholders.put("page_id", page.id());
        placeholders.put("page_title", page.title());
        return placeholders;
    }
}

package ru.refactorum.drug.config;

import ru.refactorum.drug.model.EffectSpec;

import java.util.Collections;
import java.util.List;

public final class OverdoseSettings {

    private final boolean enabled;
    private final int maxLevel;
    private final int defaultGain;
    private final int resetAfterSeconds;
    private final int checkIntervalSeconds;
    private final boolean notifyOnUse;
    private final int warningLevel;
    private final int badLevel;
    private final int criticalLevel;
    private final List<EffectSpec> warningEffects;
    private final List<EffectSpec> badEffects;
    private final List<EffectSpec> criticalEffects;
    private final boolean badTripEnabled;
    private final int badTripMinLevel;
    private final int badTripCooldownSeconds;
    private final double badTripDamage;
    private final List<EffectSpec> badTripEffects;
    private final boolean decayEnabled;
    private final int decayStartAfterSeconds;
    private final int decayIntervalSeconds;
    private final int decayAmount;

    public OverdoseSettings(
            final boolean enabled,
            final int maxLevel,
            final int defaultGain,
            final int resetAfterSeconds,
            final int checkIntervalSeconds,
            final boolean notifyOnUse,
            final int warningLevel,
            final int badLevel,
            final int criticalLevel,
            final List<EffectSpec> warningEffects,
            final List<EffectSpec> badEffects,
            final List<EffectSpec> criticalEffects,
            final boolean badTripEnabled,
            final int badTripMinLevel,
            final int badTripCooldownSeconds,
            final double badTripDamage,
            final List<EffectSpec> badTripEffects,
            final boolean decayEnabled,
            final int decayStartAfterSeconds,
            final int decayIntervalSeconds,
            final int decayAmount
    ) {
        this.enabled = enabled;
        this.maxLevel = Math.max(1, maxLevel);
        this.defaultGain = Math.max(0, defaultGain);
        this.resetAfterSeconds = Math.max(1, resetAfterSeconds);
        this.checkIntervalSeconds = Math.max(1, checkIntervalSeconds);
        this.notifyOnUse = notifyOnUse;
        this.warningLevel = clampLevel(warningLevel, this.maxLevel);
        this.badLevel = clampLevel(badLevel, this.maxLevel);
        this.criticalLevel = clampLevel(criticalLevel, this.maxLevel);
        this.warningEffects = copyEffects(warningEffects);
        this.badEffects = copyEffects(badEffects);
        this.criticalEffects = copyEffects(criticalEffects);
        this.badTripEnabled = badTripEnabled;
        this.badTripMinLevel = clampLevel(badTripMinLevel, this.maxLevel);
        this.badTripCooldownSeconds = Math.max(1, badTripCooldownSeconds);
        this.badTripDamage = Math.max(0D, badTripDamage);
        this.badTripEffects = copyEffects(badTripEffects);
        this.decayEnabled = decayEnabled;
        this.decayStartAfterSeconds = Math.max(1, decayStartAfterSeconds);
        this.decayIntervalSeconds = Math.max(1, decayIntervalSeconds);
        this.decayAmount = Math.max(1, decayAmount);
    }

    private List<EffectSpec> copyEffects(final List<EffectSpec> effects) {
        return effects == null ? Collections.emptyList() : List.copyOf(effects);
    }

    private int clampLevel(final int value, final int maxLevel) {
        return Math.max(0, Math.min(maxLevel, value));
    }

    public boolean enabled() {
        return enabled;
    }

    public int maxLevel() {
        return maxLevel;
    }

    public int defaultGain() {
        return defaultGain;
    }

    public int resetAfterSeconds() {
        return resetAfterSeconds;
    }

    public int checkIntervalSeconds() {
        return checkIntervalSeconds;
    }

    public boolean notifyOnUse() {
        return notifyOnUse;
    }

    public int warningLevel() {
        return warningLevel;
    }

    public int badLevel() {
        return badLevel;
    }

    public int criticalLevel() {
        return criticalLevel;
    }

    public List<EffectSpec> warningEffects() {
        return warningEffects;
    }

    public List<EffectSpec> badEffects() {
        return badEffects;
    }

    public List<EffectSpec> criticalEffects() {
        return criticalEffects;
    }

    public boolean badTripEnabled() {
        return badTripEnabled;
    }

    public int badTripMinLevel() {
        return badTripMinLevel;
    }

    public int badTripCooldownSeconds() {
        return badTripCooldownSeconds;
    }

    public double badTripDamage() {
        return badTripDamage;
    }

    public List<EffectSpec> badTripEffects() {
        return badTripEffects;
    }

    public boolean decayEnabled() {
        return decayEnabled;
    }

    public int decayStartAfterSeconds() {
        return decayStartAfterSeconds;
    }

    public int decayIntervalSeconds() {
        return decayIntervalSeconds;
    }

    public int decayAmount() {
        return decayAmount;
    }
}

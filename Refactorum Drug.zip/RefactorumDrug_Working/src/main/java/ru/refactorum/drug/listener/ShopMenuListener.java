package ru.refactorum.drug.listener;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import ru.refactorum.drug.RefactorumDrugPlugin;
import ru.refactorum.drug.menu.DrugShopHolder;
import ru.refactorum.drug.menu.MenuType;
import ru.refactorum.drug.model.Remedy;
import ru.refactorum.drug.model.Substance;

import java.util.Optional;

public final class ShopMenuListener implements Listener {

    private final RefactorumDrugPlugin plugin;

    public ShopMenuListener(final RefactorumDrugPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onInventoryClick(final InventoryClickEvent event) {
        final Inventory topInventory = event.getView().getTopInventory();
        if (!(topInventory.getHolder() instanceof DrugShopHolder holder)) {
            return;
        }

        event.setCancelled(true);

        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }

        if (event.getRawSlot() < 0 || event.getRawSlot() >= topInventory.getSize()) {
            return;
        }

        final ItemStack clicked = event.getCurrentItem();
        final Optional<String> action = plugin.getShopMenuService().readAction(clicked);
        if (action.isEmpty()) {
            return;
        }

        handleAction(player, holder, action.get());
    }

    @EventHandler
    public void onInventoryDrag(final InventoryDragEvent event) {
        final Inventory topInventory = event.getView().getTopInventory();
        if (!(topInventory.getHolder() instanceof DrugShopHolder)) {
            return;
        }

        for (int rawSlot : event.getRawSlots()) {
            if (rawSlot >= 0 && rawSlot < topInventory.getSize()) {
                event.setCancelled(true);
                return;
            }
        }
    }

    private void handleAction(final Player player, final DrugShopHolder holder, final String action) {
        if (action.equals("close")) {
            player.closeInventory();
            return;
        }

        if (action.equals("previous")) {
            plugin.getShopMenuService().openShop(player, holder.pageIndex());
            return;
        }

        if (action.equals("next")) {
            plugin.getShopMenuService().openShop(player, holder.pageIndex() + 2);
            return;
        }

        if (action.equals("remedies")) {
            plugin.getShopMenuService().openRemedies(player, holder.pageIndex());
            return;
        }

        if (action.equals("back")) {
            handleBack(player, holder);
            return;
        }

        if (action.startsWith("substance:")) {
            handleSubstance(player, holder, action.substring("substance:".length()));
            return;
        }

        if (action.startsWith("remedy:")) {
            handleRemedy(player, holder, action.substring("remedy:".length()));
            return;
        }

        if (action.equals("confirm")) {
            handleConfirm(player, holder);
        }
    }

    private void handleBack(final Player player, final DrugShopHolder holder) {
        if (holder.menuType() == MenuType.REMEDIES) {
            plugin.getShopMenuService().openShop(player, holder.pageIndex() + 1);
            return;
        }

        if (holder.menuType() == MenuType.REMEDY_PURCHASE) {
            plugin.getShopMenuService().openRemedies(player, holder.pageIndex());
            return;
        }

        plugin.getShopMenuService().openShop(player, holder.pageIndex() + 1);
    }

    private void handleSubstance(final Player player, final DrugShopHolder holder, final String substanceId) {
        final Optional<Substance> substance = plugin.getShopConfig().substance(substanceId);
        if (substance.isEmpty()) {
            plugin.getMessages().send(player, "shop.substance-not-found");
            player.closeInventory();
            return;
        }

        if (substance.get().hasPermissionRestriction() && !player.hasPermission(substance.get().permission())) {
            plugin.getMessages().send(player, "shop.no-permission-substance");
            return;
        }

        plugin.getShopMenuService().openPurchase(player, substance.get(), holder.pageIndex());
    }

    private void handleRemedy(final Player player, final DrugShopHolder holder, final String remedyId) {
        final Optional<Remedy> remedy = plugin.getShopConfig().remedy(remedyId);
        if (remedy.isEmpty()) {
            plugin.getMessages().send(player, "remedy.not-found");
            player.closeInventory();
            return;
        }

        if (remedy.get().hasPermissionRestriction() && !player.hasPermission(remedy.get().permission())) {
            plugin.getMessages().send(player, "remedy.no-permission");
            return;
        }

        plugin.getShopMenuService().openRemedyPurchase(player, remedy.get(), holder.pageIndex());
    }

    private void handleConfirm(final Player player, final DrugShopHolder holder) {
        if (holder.menuType() == MenuType.PURCHASE) {
            final Optional<Substance> substance = plugin.getShopConfig().substance(holder.entryId());
            if (substance.isEmpty()) {
                plugin.getMessages().send(player, "shop.substance-not-found");
                player.closeInventory();
                return;
            }

            final boolean purchased = plugin.getSubstanceService().purchase(player, substance.get());
            if (!purchased) {
                return;
            }

            if (plugin.getShopConfig().purchaseGui().closeAfterBuy()) {
                player.closeInventory();
            } else {
                plugin.getShopMenuService().openPurchase(player, substance.get(), holder.pageIndex());
            }
            return;
        }

        if (holder.menuType() == MenuType.REMEDY_PURCHASE) {
            final Optional<Remedy> remedy = plugin.getShopConfig().remedy(holder.entryId());
            if (remedy.isEmpty()) {
                plugin.getMessages().send(player, "remedy.not-found");
                player.closeInventory();
                return;
            }

            final boolean purchased = plugin.getRemedyService().purchase(player, remedy.get());
            if (!purchased) {
                return;
            }

            if (plugin.getShopConfig().remedyPurchaseGui().closeAfterBuy()) {
                player.closeInventory();
            } else {
                plugin.getShopMenuService().openRemedyPurchase(player, remedy.get(), holder.pageIndex());
            }
        }
    }
}

package ru.refactorum.drug.model;

import org.bukkit.Material;

import java.util.Collections;
import java.util.List;

public final class Substance {

    private final String id;
    private final String pageId;
    private final int slot;
    private final Material material;
    private final int amount;
    private final double price;
    private final String permission;
    private final boolean hideWithoutPermission;
    private final int customModelData;
    private final String displayName;
    private final List<String> lore;
    private final int addictionGain;
    private final int overdoseGain;
    private final List<EffectSpec> effects;

    public Substance(
            final String id,
            final String pageId,
            final int slot,
            final Material material,
            final int amount,
            final double price,
            final String permission,
            final boolean hideWithoutPermission,
            final int customModelData,
            final String displayName,
            final List<String> lore,
            final int addictionGain,
            final int overdoseGain,
            final List<EffectSpec> effects
    ) {
        this.id = id;
        this.pageId = pageId;
        this.slot = slot;
        this.material = material;
        this.amount = Math.max(1, Math.min(64, amount));
        this.price = Math.max(0D, price);
        this.permission = permission == null ? "" : permission;
        this.hideWithoutPermission = hideWithoutPermission;
        this.customModelData = Math.max(0, customModelData);
        this.displayName = displayName == null ? id : displayName;
        this.lore = lore == null ? Collections.emptyList() : List.copyOf(lore);
        this.addictionGain = Math.max(0, addictionGain);
        this.overdoseGain = Math.max(0, overdoseGain);
        this.effects = effects == null ? Collections.emptyList() : List.copyOf(effects);
    }

    public String id() {
        return id;
    }

    public String pageId() {
        return pageId;
    }

    public int slot() {
        return slot;
    }

    public Material material() {
        return material;
    }

    public int amount() {
        return amount;
    }

    public double price() {
        return price;
    }

    public String permission() {
        return permission;
    }

    public boolean hasPermissionRestriction() {
        return !permission.isBlank();
    }

    public boolean hideWithoutPermission() {
        return hideWithoutPermission;
    }

    public int customModelData() {
        return customModelData;
    }

    public String displayName() {
        return displayName;
    }

    public List<String> lore() {
        return lore;
    }

    public int addictionGain() {
        return addictionGain;
    }

    public int overdoseGain() {
        return overdoseGain;
    }

    public List<EffectSpec> effects() {
        return effects;
    }
}

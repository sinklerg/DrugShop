package ru.refactorum.drug.config;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;

public final class ButtonConfig {

    private final int slot;
    private final ConfigItem item;

    public ButtonConfig(final int slot, final ConfigItem item) {
        this.slot = slot;
        this.item = item;
    }

    public static ButtonConfig fromSection(
            final ConfigurationSection section,
            final int fallbackSlot,
            final Material fallbackMaterial
    ) {
        if (section == null) {
            return new ButtonConfig(fallbackSlot, new ConfigItem(fallbackMaterial, 1, "", java.util.List.of(), 0, true));
        }
        return new ButtonConfig(
                section.getInt("slot", fallbackSlot),
                ConfigItem.fromSection(section, fallbackMaterial)
        );
    }

    public int slot() {
        return slot;
    }

    public ConfigItem item() {
        return item;
    }
}

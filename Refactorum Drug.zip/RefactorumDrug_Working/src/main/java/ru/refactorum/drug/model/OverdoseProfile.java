package ru.refactorum.drug.model;

import java.util.UUID;

public final class OverdoseProfile {

    private final UUID uniqueId;
    private int level;
    private long lastUseMillis;
    private long lastDecayMillis;
    private long lastBadTripMillis;

    public OverdoseProfile(
            final UUID uniqueId,
            final int level,
            final long lastUseMillis,
            final long lastDecayMillis,
            final long lastBadTripMillis
    ) {
        this.uniqueId = uniqueId;
        this.level = Math.max(0, level);
        this.lastUseMillis = Math.max(0L, lastUseMillis);
        this.lastDecayMillis = Math.max(0L, lastDecayMillis);
        this.lastBadTripMillis = Math.max(0L, lastBadTripMillis);
    }

    public static OverdoseProfile empty(final UUID uniqueId) {
        return new OverdoseProfile(uniqueId, 0, 0L, 0L, 0L);
    }

    public UUID uniqueId() {
        return uniqueId;
    }

    public int level() {
        return level;
    }

    public void setLevel(final int level) {
        this.level = Math.max(0, level);
    }

    public void increase(final int amount, final int maxLevel) {
        this.level = Math.max(0, Math.min(Math.max(1, maxLevel), this.level + Math.max(0, amount)));
    }

    public void decrease(final int amount) {
        this.level = Math.max(0, this.level - Math.max(0, amount));
    }

    public long lastUseMillis() {
        return lastUseMillis;
    }

    public void setLastUseMillis(final long lastUseMillis) {
        this.lastUseMillis = Math.max(0L, lastUseMillis);
    }

    public long lastDecayMillis() {
        return lastDecayMillis;
    }

    public void setLastDecayMillis(final long lastDecayMillis) {
        this.lastDecayMillis = Math.max(0L, lastDecayMillis);
    }

    public long lastBadTripMillis() {
        return lastBadTripMillis;
    }

    public void setLastBadTripMillis(final long lastBadTripMillis) {
        this.lastBadTripMillis = Math.max(0L, lastBadTripMillis);
    }
}

package ru.refactorum.drug.model;

import java.util.UUID;

public final class AddictionProfile {

    private final UUID uniqueId;
    private int level;
    private long lastUseMillis;
    private long lastDecayMillis;
    private long lastWithdrawalMillis;
    private long lastWithdrawalMessageMillis;
    private String lastSubstanceId;

    public AddictionProfile(
            final UUID uniqueId,
            final int level,
            final long lastUseMillis,
            final long lastDecayMillis,
            final long lastWithdrawalMillis,
            final long lastWithdrawalMessageMillis,
            final String lastSubstanceId
    ) {
        this.uniqueId = uniqueId;
        this.level = Math.max(0, level);
        this.lastUseMillis = Math.max(0L, lastUseMillis);
        this.lastDecayMillis = Math.max(0L, lastDecayMillis);
        this.lastWithdrawalMillis = Math.max(0L, lastWithdrawalMillis);
        this.lastWithdrawalMessageMillis = Math.max(0L, lastWithdrawalMessageMillis);
        this.lastSubstanceId = lastSubstanceId == null ? "" : lastSubstanceId;
    }

    public static AddictionProfile empty(final UUID uniqueId) {
        return new AddictionProfile(uniqueId, 0, 0L, 0L, 0L, 0L, "");
    }

    public UUID uniqueId() {
        return uniqueId;
    }

    public int level() {
        return level;
    }

    public void setLevel(final int level) {
        this.level = Math.max(0, level);
    }

    public void increase(final int amount, final int maxLevel) {
        this.level = Math.max(0, Math.min(Math.max(1, maxLevel), this.level + Math.max(0, amount)));
    }

    public void decrease(final int amount) {
        this.level = Math.max(0, this.level - Math.max(0, amount));
    }

    public long lastUseMillis() {
        return lastUseMillis;
    }

    public void setLastUseMillis(final long lastUseMillis) {
        this.lastUseMillis = Math.max(0L, lastUseMillis);
    }

    public long lastDecayMillis() {
        return lastDecayMillis;
    }

    public void setLastDecayMillis(final long lastDecayMillis) {
        this.lastDecayMillis = Math.max(0L, lastDecayMillis);
    }

    public long lastWithdrawalMillis() {
        return lastWithdrawalMillis;
    }

    public void setLastWithdrawalMillis(final long lastWithdrawalMillis) {
        this.lastWithdrawalMillis = Math.max(0L, lastWithdrawalMillis);
    }

    public long lastWithdrawalMessageMillis() {
        return lastWithdrawalMessageMillis;
    }

    public void setLastWithdrawalMessageMillis(final long lastWithdrawalMessageMillis) {
        this.lastWithdrawalMessageMillis = Math.max(0L, lastWithdrawalMessageMillis);
    }

    public String lastSubstanceId() {
        return lastSubstanceId;
    }

    public void setLastSubstanceId(final String lastSubstanceId) {
        this.lastSubstanceId = lastSubstanceId == null ? "" : lastSubstanceId;
    }
}

package ru.refactorum.drug.service;

import net.kyori.adventure.text.Component;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import ru.refactorum.drug.RefactorumDrugPlugin;
import ru.refactorum.drug.model.EffectSpec;
import ru.refactorum.drug.model.Remedy;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

public final class RemedyService {

    private static final String[] ROMAN_LEVELS = {
            "", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"
    };

    private final RefactorumDrugPlugin plugin;

    public RemedyService(final RefactorumDrugPlugin plugin) {
        this.plugin = Objects.requireNonNull(plugin, "plugin");
    }

    public Optional<Remedy> fromItem(final ItemStack item) {
        if (item == null || item.getType().isAir()) {
            return Optional.empty();
        }

        final ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return Optional.empty();
        }

        final String id = meta.getPersistentDataContainer().get(plugin.remedyKey(), PersistentDataType.STRING);
        return plugin.getShopConfig().remedy(id);
    }

    public ItemStack createRemedyItem(final Remedy remedy) {
        final ItemStack item = new ItemStack(remedy.material(), remedy.amount());
        final ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return item;
        }

        final Map<String, String> placeholders = placeholders(remedy);
        meta.displayName(plugin.getMessages().deserialize(remedy.displayName(), placeholders));

        final List<Component> lore = plugin.getMessages().deserializeList(remedy.lore(), placeholders);
        meta.lore(lore);

        if (remedy.customModelData() > 0) {
            meta.setCustomModelData(remedy.customModelData());
        }

        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
        meta.getPersistentDataContainer().set(plugin.remedyKey(), PersistentDataType.STRING, remedy.id());
        item.setItemMeta(meta);
        return item;
    }

    public boolean purchase(final Player player, final Remedy remedy) {
        if (remedy.hasPermissionRestriction() && !player.hasPermission(remedy.permission())) {
            plugin.getMessages().send(player, "remedy.no-permission");
            return false;
        }

        final CurrencyService currencyService = plugin.getCurrencyService();
        final PlayerInventory inventory = player.getInventory();
        final Map<String, String> placeholders = placeholders(remedy);
        placeholders.put("balance", currencyService.format(currencyService.balance(player)));

        if (!currencyService.ready()) {
            plugin.getMessages().send(player, "shop.economy-unavailable", placeholders);
            return false;
        }

        if (!currencyService.has(player, remedy.price())) {
            plugin.getMessages().send(player, "shop.not-enough-currency", placeholders);
            return false;
        }

        final ItemStack reward = createRemedyItem(remedy);
        if (!plugin.getShopConfig().dropOverflowItems() && !canFit(inventory, reward)) {
            plugin.getMessages().send(player, "shop.inventory-full", placeholders);
            return false;
        }

        if (!currencyService.withdraw(player, remedy.price())) {
            plugin.getMessages().send(player, "shop.payment-error", placeholders);
            return false;
        }

        final Map<Integer, ItemStack> leftovers = inventory.addItem(reward);
        if (!leftovers.isEmpty()) {
            leftovers.values().forEach(leftover -> player.getWorld().dropItemNaturally(player.getLocation(), leftover));
            plugin.getMessages().send(player, "shop.inventory-full-dropped", placeholders);
        }

        plugin.getMessages().send(player, "remedy.purchase-success", placeholders);
        return true;
    }

    public void use(final Player player, final EquipmentSlot hand, final ItemStack item, final Remedy remedy) {
        if (remedy.hasPermissionRestriction() && !player.hasPermission(remedy.permission())) {
            plugin.getMessages().send(player, "remedy.no-permission");
            return;
        }

        final int oldOverdose = plugin.getOverdoseService().level(player.getUniqueId());
        final int oldAddiction = plugin.getAddictionService().level(player.getUniqueId());
        final boolean canAffectOverdose = plugin.getShopConfig().overdose().enabled() && remedy.overdoseDecrease() > 0 && oldOverdose > 0;
        final boolean canAffectAddiction = plugin.getShopConfig().addiction().enabled() && remedy.addictionDecrease() > 0 && oldAddiction > 0;

        if (!canAffectOverdose && !canAffectAddiction) {
            plugin.getMessages().send(player, "remedy.nothing-to-treat", placeholders(remedy));
            return;
        }

        for (EffectSpec effect : remedy.effects()) {
            player.addPotionEffect(effect.toPotionEffect(), true);
        }

        final int overdoseReduced = canAffectOverdose ? plugin.getOverdoseService().reduce(player, remedy.overdoseDecrease()) : 0;
        final int addictionReduced = canAffectAddiction ? plugin.getAddictionService().decrease(player, remedy.addictionDecrease()) : 0;
        decreaseItem(player, hand, item);
        playUseSound(player);

        final Map<String, String> placeholders = placeholders(remedy);
        placeholders.put("overdose_before", String.valueOf(oldOverdose));
        placeholders.put("overdose_after", String.valueOf(plugin.getOverdoseService().level(player.getUniqueId())));
        placeholders.put("overdose_removed", String.valueOf(overdoseReduced));
        placeholders.put("addiction_before", String.valueOf(oldAddiction));
        placeholders.put("addiction_after", String.valueOf(plugin.getAddictionService().level(player.getUniqueId())));
        placeholders.put("addiction_removed", String.valueOf(addictionReduced));
        plugin.getMessages().send(player, "remedy.used", placeholders);
    }

    public Map<String, String> placeholders(final Remedy remedy) {
        final Map<String, String> placeholders = new HashMap<>(plugin.getShopConfig().basePlaceholders());
        placeholders.put("id", remedy.id());
        placeholders.put("remedy", remedy.displayName());
        placeholders.put("remedy_name", remedy.displayName());
        placeholders.put("amount", String.valueOf(remedy.amount()));
        placeholders.put("price", plugin.getCurrencyService().format(remedy.price()));
        placeholders.put("effects", effectList(remedy.effects()));
        placeholders.put("overdose_decrease", String.valueOf(remedy.overdoseDecrease()));
        placeholders.put("addiction_decrease", String.valueOf(remedy.addictionDecrease()));
        return placeholders;
    }

    private String effectList(final List<EffectSpec> effects) {
        if (effects.isEmpty()) {
            return "<gray>нет эффектов</gray>";
        }

        return effects.stream()
                .map(effect -> "<gray>" + effectName(effect) + " " + roman(effect.level()) + " " + effect.durationSeconds() + "с</gray>")
                .toList()
                .stream()
                .reduce((left, right) -> left + "<dark_gray>,</dark_gray> " + right)
                .orElse("<gray>нет эффектов</gray>");
    }

    private String effectName(final EffectSpec effect) {
        final NamespacedKey key = Registry.EFFECT.getKey(effect.type());
        if (key == null) {
            return effect.type().toString().toLowerCase(Locale.ROOT);
        }
        return key.getKey();
    }

    private String roman(final int level) {
        if (level > 0 && level < ROMAN_LEVELS.length) {
            return ROMAN_LEVELS[level];
        }
        return String.valueOf(level);
    }

    private boolean canFit(final PlayerInventory inventory, final ItemStack itemToAdd) {
        int remaining = itemToAdd.getAmount();
        final int maxStackSize = itemToAdd.getMaxStackSize();

        for (ItemStack content : inventory.getStorageContents()) {
            if (content == null || content.getType().isAir()) {
                remaining -= maxStackSize;
            } else if (content.isSimilar(itemToAdd)) {
                remaining -= Math.max(0, maxStackSize - content.getAmount());
            }

            if (remaining <= 0) {
                return true;
            }
        }
        return false;
    }

    private void decreaseItem(final Player player, final EquipmentSlot hand, final ItemStack item) {
        final ItemStack updated = item.clone();
        updated.setAmount(item.getAmount() - 1);

        if (updated.getAmount() <= 0) {
            if (hand == EquipmentSlot.OFF_HAND) {
                player.getInventory().setItemInOffHand(null);
            } else {
                player.getInventory().setItemInMainHand(null);
            }
            return;
        }

        if (hand == EquipmentSlot.OFF_HAND) {
            player.getInventory().setItemInOffHand(updated);
        } else {
            player.getInventory().setItemInMainHand(updated);
        }
    }

    private void playUseSound(final Player player) {
        if (!plugin.getShopConfig().useSoundEnabled()) {
            return;
        }

        try {
            final Sound sound = Sound.valueOf(plugin.getShopConfig().useSoundName().toUpperCase(Locale.ROOT));
            player.playSound(player.getLocation(), sound, plugin.getShopConfig().useSoundVolume(), plugin.getShopConfig().useSoundPitch());
        } catch (IllegalArgumentException ignored) {
            plugin.getLogger().warning("Invalid sound in config: " + plugin.getShopConfig().useSoundName());
        }
    }
}

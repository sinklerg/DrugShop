package ru.refactorum.drug.model;

import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public final class EffectSpec {

    private final PotionEffectType type;
    private final int durationTicks;
    private final int level;
    private final boolean ambient;
    private final boolean particles;
    private final boolean icon;

    public EffectSpec(
            final PotionEffectType type,
            final int durationTicks,
            final int level,
            final boolean ambient,
            final boolean particles,
            final boolean icon
    ) {
        this.type = type;
        this.durationTicks = Math.max(1, durationTicks);
        this.level = Math.max(1, level);
        this.ambient = ambient;
        this.particles = particles;
        this.icon = icon;
    }

    public PotionEffect toPotionEffect() {
        return new PotionEffect(type, durationTicks, level - 1, ambient, particles, icon);
    }

    public PotionEffectType type() {
        return type;
    }

    public int durationTicks() {
        return durationTicks;
    }

    public int durationSeconds() {
        return Math.max(1, durationTicks / 20);
    }

    public int level() {
        return level;
    }
}

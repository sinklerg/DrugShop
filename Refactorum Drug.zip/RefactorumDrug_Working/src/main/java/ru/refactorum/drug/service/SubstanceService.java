package ru.refactorum.drug.service;

import net.kyori.adventure.text.Component;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import ru.refactorum.drug.RefactorumDrugPlugin;
import ru.refactorum.drug.model.EffectSpec;
import ru.refactorum.drug.model.Substance;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class SubstanceService {

    private static final String[] ROMAN_LEVELS = {
            "", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"
    };

    private final RefactorumDrugPlugin plugin;
    private final Map<UUID, Long> cooldowns = new ConcurrentHashMap<>();

    public SubstanceService(final RefactorumDrugPlugin plugin) {
        this.plugin = Objects.requireNonNull(plugin, "plugin");
    }

    public Optional<Substance> fromItem(final ItemStack item) {
        if (item == null || item.getType().isAir()) {
            return Optional.empty();
        }

        final ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return Optional.empty();
        }

        final String id = meta.getPersistentDataContainer().get(plugin.substanceKey(), PersistentDataType.STRING);
        return plugin.getShopConfig().substance(id);
    }

    public ItemStack createSubstanceItem(final Substance substance) {
        final ItemStack item = new ItemStack(substance.material(), substance.amount());
        final ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return item;
        }

        final Map<String, String> placeholders = placeholders(substance);
        meta.displayName(plugin.getMessages().deserialize(substance.displayName(), placeholders));

        final List<Component> lore = plugin.getMessages().deserializeList(substance.lore(), placeholders);
        meta.lore(lore);

        if (substance.customModelData() > 0) {
            meta.setCustomModelData(substance.customModelData());
        }

        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
        meta.getPersistentDataContainer().set(plugin.substanceKey(), PersistentDataType.STRING, substance.id());
        item.setItemMeta(meta);
        return item;
    }

    public boolean purchase(final Player player, final Substance substance) {
        if (substance.hasPermissionRestriction() && !player.hasPermission(substance.permission())) {
            plugin.getMessages().send(player, "shop.no-permission-substance");
            return false;
        }

        final CurrencyService currencyService = plugin.getCurrencyService();
        final PlayerInventory inventory = player.getInventory();
        final Map<String, String> placeholders = placeholders(substance);
        placeholders.put("balance", currencyService.format(currencyService.balance(player)));

        if (!currencyService.ready()) {
            plugin.getMessages().send(player, "shop.economy-unavailable", placeholders);
            return false;
        }

        if (!currencyService.has(player, substance.price())) {
            plugin.getMessages().send(player, "shop.not-enough-currency", placeholders);
            return false;
        }

        final ItemStack reward = createSubstanceItem(substance);
        if (!plugin.getShopConfig().dropOverflowItems() && !canFit(inventory, reward)) {
            plugin.getMessages().send(player, "shop.inventory-full", placeholders);
            return false;
        }

        if (!currencyService.withdraw(player, substance.price())) {
            plugin.getMessages().send(player, "shop.payment-error", placeholders);
            return false;
        }

        final Map<Integer, ItemStack> leftovers = inventory.addItem(reward);
        if (!leftovers.isEmpty()) {
            leftovers.values().forEach(leftover -> player.getWorld().dropItemNaturally(player.getLocation(), leftover));
            plugin.getMessages().send(player, "shop.inventory-full-dropped", placeholders);
        }

        plugin.getMessages().send(player, "shop.purchase-success", placeholders);
        return true;
    }

    public void consume(final Player player, final EquipmentSlot hand, final ItemStack item, final Substance substance) {
        if (substance.hasPermissionRestriction() && !player.hasPermission(substance.permission())) {
            plugin.getMessages().send(player, "consume.no-permission");
            return;
        }

        final long now = System.currentTimeMillis();
        final long availableAt = cooldowns.getOrDefault(player.getUniqueId(), 0L);
        if (availableAt > now) {
            final long remainingSeconds = Math.max(1L, (long) Math.ceil((availableAt - now) / 1000.0D));
            plugin.getMessages().send(player, "consume.cooldown", Map.of("seconds", String.valueOf(remainingSeconds)));
            return;
        }

        for (EffectSpec effect : substance.effects()) {
            player.addPotionEffect(effect.toPotionEffect(), true);
        }

        decreaseItem(player, hand, item);
        playUseSound(player);
        cooldowns.put(player.getUniqueId(), now + plugin.getShopConfig().consumeCooldownSeconds() * 1000L);
        plugin.getMessages().send(player, "consume.used", placeholders(substance));
        plugin.getAddictionService().recordUse(player, substance);
        plugin.getOverdoseService().recordUse(player, substance);
    }

    public Map<String, String> placeholders(final Substance substance) {
        final Map<String, String> placeholders = new HashMap<>(plugin.getShopConfig().basePlaceholders());
        placeholders.put("id", substance.id());
        placeholders.put("substance", substance.displayName());
        placeholders.put("substance_name", substance.displayName());
        placeholders.put("amount", String.valueOf(substance.amount()));
        placeholders.put("price", plugin.getCurrencyService().format(substance.price()));
        placeholders.put("effects", effectList(substance.effects()));
        placeholders.put("addiction_gain", String.valueOf(substance.addictionGain()));
        placeholders.put("overdose_gain", String.valueOf(substance.overdoseGain()));
        return placeholders;
    }

    private String effectList(final List<EffectSpec> effects) {
        if (effects.isEmpty()) {
            return "<gray>нет эффектов</gray>";
        }

        return effects.stream()
                .map(effect -> "<gray>" + effectName(effect) + " " + roman(effect.level()) + " " + effect.durationSeconds() + "с</gray>")
                .toList()
                .stream()
                .reduce((left, right) -> left + "<dark_gray>,</dark_gray> " + right)
                .orElse("<gray>нет эффектов</gray>");
    }

    private String effectName(final EffectSpec effect) {
        final NamespacedKey key = Registry.EFFECT.getKey(effect.type());
        if (key == null) {
            return effect.type().toString().toLowerCase(Locale.ROOT);
        }
        return key.getKey();
    }

    private String roman(final int level) {
        if (level > 0 && level < ROMAN_LEVELS.length) {
            return ROMAN_LEVELS[level];
        }
        return String.valueOf(level);
    }

    private boolean canFit(final PlayerInventory inventory, final ItemStack itemToAdd) {
        int remaining = itemToAdd.getAmount();
        final int maxStackSize = itemToAdd.getMaxStackSize();

        for (ItemStack content : inventory.getStorageContents()) {
            if (content == null || content.getType().isAir()) {
                remaining -= maxStackSize;
            } else if (content.isSimilar(itemToAdd)) {
                remaining -= Math.max(0, maxStackSize - content.getAmount());
            }

            if (remaining <= 0) {
                return true;
            }
        }
        return false;
    }

    private void decreaseItem(final Player player, final EquipmentSlot hand, final ItemStack item) {
        final ItemStack updated = item.clone();
        updated.setAmount(item.getAmount() - 1);

        if (updated.getAmount() <= 0) {
            if (hand == EquipmentSlot.OFF_HAND) {
                player.getInventory().setItemInOffHand(null);
            } else {
                player.getInventory().setItemInMainHand(null);
            }
            return;
        }

        if (hand == EquipmentSlot.OFF_HAND) {
            player.getInventory().setItemInOffHand(updated);
        } else {
            player.getInventory().setItemInMainHand(updated);
        }
    }

    private void playUseSound(final Player player) {
        if (!plugin.getShopConfig().useSoundEnabled()) {
            return;
        }

        try {
            final Sound sound = Sound.valueOf(plugin.getShopConfig().useSoundName().toUpperCase(Locale.ROOT));
            player.playSound(player.getLocation(), sound, plugin.getShopConfig().useSoundVolume(), plugin.getShopConfig().useSoundPitch());
        } catch (IllegalArgumentException ignored) {
            plugin.getLogger().warning("Invalid sound in config: " + plugin.getShopConfig().useSoundName());
        }
    }
}

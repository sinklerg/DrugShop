package ru.refactorum.drug;

import org.bukkit.NamespacedKey;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;
import ru.refactorum.drug.command.DrugShopCommand;
import ru.refactorum.drug.config.ShopConfig;
import ru.refactorum.drug.listener.ShopMenuListener;
import ru.refactorum.drug.listener.SubstanceUseListener;
import ru.refactorum.drug.service.AddictionService;
import ru.refactorum.drug.service.CurrencyService;
import ru.refactorum.drug.service.MessageService;
import ru.refactorum.drug.service.OverdoseService;
import ru.refactorum.drug.service.RemedyService;
import ru.refactorum.drug.service.ShopMenuService;
import ru.refactorum.drug.service.SubstanceService;

import java.io.File;
import java.util.Objects;

public final class RefactorumDrugPlugin extends JavaPlugin {

    private NamespacedKey substanceKey;
    private NamespacedKey remedyKey;
    private NamespacedKey actionKey;
    private MessageService messages;
    private ShopConfig shopConfig;
    private CurrencyService currencyService;
    private SubstanceService substanceService;
    private RemedyService remedyService;
    private ShopMenuService shopMenuService;
    private AddictionService addictionService;
    private OverdoseService overdoseService;

    @Override
    public void onEnable() {
        this.substanceKey = new NamespacedKey(this, "substance_id");
        this.remedyKey = new NamespacedKey(this, "remedy_id");
        this.actionKey = new NamespacedKey(this, "menu_action");

        saveDefaultConfig();
        saveMessagesFile();
        reloadLocalData();

        final DrugShopCommand commandExecutor = new DrugShopCommand(this);
        final PluginCommand drugShopCommand = Objects.requireNonNull(getCommand("drugshop"), "drugshop command is missing in plugin.yml");
        drugShopCommand.setExecutor(commandExecutor);
        drugShopCommand.setTabCompleter(commandExecutor);

        getServer().getPluginManager().registerEvents(new ShopMenuListener(this), this);
        getServer().getPluginManager().registerEvents(new SubstanceUseListener(this), this);

        getLogger().info("RefactorumDrug enabled. Pages: " + shopConfig.pages().size()
                + ", substances: " + shopConfig.substancesById().size()
                + ", remedies: " + shopConfig.remediesById().size());
    }

    @Override
    public void onDisable() {
        if (addictionService != null) {
            addictionService.shutdown();
        }
        if (overdoseService != null) {
            overdoseService.shutdown();
        }
    }

    public void reloadLocalData() {
        if (this.addictionService != null) {
            this.addictionService.shutdown();
        }
        if (this.overdoseService != null) {
            this.overdoseService.shutdown();
        }

        reloadConfig();
        saveMessagesFile();
        this.messages = new MessageService(this);
        this.shopConfig = new ShopConfig(this, getConfig());
        this.currencyService = new CurrencyService(this);
        this.overdoseService = new OverdoseService(this);
        this.addictionService = new AddictionService(this);
        this.substanceService = new SubstanceService(this);
        this.remedyService = new RemedyService(this);
        this.shopMenuService = new ShopMenuService(this);
    }

    private void saveMessagesFile() {
        final File messagesFile = new File(getDataFolder(), "messages.yml");
        if (!messagesFile.exists()) {
            saveResource("messages.yml", false);
        }
    }

    public NamespacedKey substanceKey() {
        return substanceKey;
    }

    public NamespacedKey remedyKey() {
        return remedyKey;
    }

    public NamespacedKey actionKey() {
        return actionKey;
    }

    public MessageService getMessages() {
        return messages;
    }

    public ShopConfig getShopConfig() {
        return shopConfig;
    }

    public CurrencyService getCurrencyService() {
        return currencyService;
    }

    public SubstanceService getSubstanceService() {
        return substanceService;
    }

    public RemedyService getRemedyService() {
        return remedyService;
    }

    public ShopMenuService getShopMenuService() {
        return shopMenuService;
    }

    public AddictionService getAddictionService() {
        return addictionService;
    }

    public OverdoseService getOverdoseService() {
        return overdoseService;
    }
}

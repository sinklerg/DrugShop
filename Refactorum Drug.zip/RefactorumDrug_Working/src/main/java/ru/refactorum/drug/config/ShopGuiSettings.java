package ru.refactorum.drug.config;

import java.util.List;

public final class ShopGuiSettings {

    private final int size;
    private final String title;
    private final boolean fillEnabled;
    private final ConfigItem fillItem;
    private final ButtonConfig previousButton;
    private final ButtonConfig closeButton;
    private final ButtonConfig nextButton;
    private final ButtonConfig remediesButton;
    private final List<String> priceLore;

    public ShopGuiSettings(
            final int size,
            final String title,
            final boolean fillEnabled,
            final ConfigItem fillItem,
            final ButtonConfig previousButton,
            final ButtonConfig closeButton,
            final ButtonConfig nextButton,
            final ButtonConfig remediesButton,
            final List<String> priceLore
    ) {
        this.size = size;
        this.title = title;
        this.fillEnabled = fillEnabled;
        this.fillItem = fillItem;
        this.previousButton = previousButton;
        this.closeButton = closeButton;
        this.nextButton = nextButton;
        this.remediesButton = remediesButton;
        this.priceLore = List.copyOf(priceLore);
    }

    public int size() {
        return size;
    }

    public String title() {
        return title;
    }

    public boolean fillEnabled() {
        return fillEnabled;
    }

    public ConfigItem fillItem() {
        return fillItem;
    }

    public ButtonConfig previousButton() {
        return previousButton;
    }

    public ButtonConfig closeButton() {
        return closeButton;
    }

    public ButtonConfig nextButton() {
        return nextButton;
    }

    public ButtonConfig remediesButton() {
        return remediesButton;
    }

    public List<String> priceLore() {
        return priceLore;
    }
}

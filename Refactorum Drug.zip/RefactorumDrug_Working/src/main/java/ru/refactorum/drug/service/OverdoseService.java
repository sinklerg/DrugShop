package ru.refactorum.drug.service;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;
import ru.refactorum.drug.RefactorumDrugPlugin;
import ru.refactorum.drug.config.OverdoseSettings;
import ru.refactorum.drug.model.EffectSpec;
import ru.refactorum.drug.model.OverdoseProfile;
import ru.refactorum.drug.model.Substance;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

public final class OverdoseService {

    private static final long MILLIS_PER_SECOND = 1000L;

    private final RefactorumDrugPlugin plugin;
    private final File dataFile;
    private final Map<UUID, OverdoseProfile> profiles = new LinkedHashMap<>();
    private BukkitTask task;

    public OverdoseService(final RefactorumDrugPlugin plugin) {
        this.plugin = Objects.requireNonNull(plugin, "plugin");
        this.dataFile = new File(plugin.getDataFolder(), "overdoses.yml");
        loadAll();
        startTask();
    }

    public void shutdown() {
        if (task != null) {
            task.cancel();
            task = null;
        }
        saveAll();
    }

    public void recordUse(final Player player, final Substance substance) {
        final OverdoseSettings settings = settings();
        if (!settings.enabled()) {
            return;
        }

        final int gain = Math.max(0, substance.overdoseGain());
        if (gain <= 0) {
            return;
        }

        final long now = System.currentTimeMillis();
        final OverdoseProfile profile = profile(player.getUniqueId());
        if (profile.lastUseMillis() > 0L && now - profile.lastUseMillis() >= secondsToMillis(settings.resetAfterSeconds())) {
            profile.setLevel(0);
        }

        final int previousLevel = profile.level();
        profile.increase(gain, settings.maxLevel());
        profile.setLastUseMillis(now);
        profile.setLastDecayMillis(now);

        applyStageEffects(player, profile.level(), settings);

        final Map<String, String> placeholders = placeholders(player, profile, gain, 0);
        if (tryBadTrip(player, profile, settings, now, placeholders)) {
            saveAll();
            return;
        }

        final String thresholdMessage = thresholdMessage(previousLevel, profile.level(), settings);
        if (thresholdMessage != null) {
            plugin.getMessages().send(player, thresholdMessage, placeholders);
        } else if (settings.notifyOnUse()) {
            plugin.getMessages().send(player, "overdose.increased", placeholders);
        }

        saveAll();
    }

    public int reduce(final Player player, final int amount) {
        final OverdoseSettings settings = settings();
        if (!settings.enabled()) {
            return 0;
        }

        final OverdoseProfile profile = profile(player.getUniqueId());
        final int previousLevel = profile.level();
        profile.decrease(amount);
        if (profile.level() <= 0) {
            profile.setLastUseMillis(0L);
            profile.setLastDecayMillis(0L);
            profile.setLastBadTripMillis(0L);
        }
        saveAll();
        return Math.max(0, previousLevel - profile.level());
    }

    public int level(final UUID uniqueId) {
        return profile(uniqueId).level();
    }

    public Map<String, String> placeholders(final Player player, final int gain, final int decrease) {
        return placeholders(player, profile(player.getUniqueId()), gain, decrease);
    }

    private boolean tryBadTrip(
            final Player player,
            final OverdoseProfile profile,
            final OverdoseSettings settings,
            final long now,
            final Map<String, String> placeholders
    ) {
        if (!settings.badTripEnabled()) {
            return false;
        }

        if (profile.level() < settings.badTripMinLevel()) {
            return false;
        }

        if (now - profile.lastBadTripMillis() < secondsToMillis(settings.badTripCooldownSeconds())) {
            return false;
        }

        for (EffectSpec effect : settings.badTripEffects()) {
            player.addPotionEffect(effect.toPotionEffect(), true);
        }

        if (settings.badTripDamage() > 0D && player.getHealth() > 0D) {
            player.damage(settings.badTripDamage());
        }

        profile.setLastBadTripMillis(now);
        plugin.getMessages().send(player, "overdose.badtrip", placeholders);
        return true;
    }

    private void applyStageEffects(final Player player, final int level, final OverdoseSettings settings) {
        final List<EffectSpec> effects;
        if (level >= settings.criticalLevel()) {
            effects = settings.criticalEffects();
        } else if (level >= settings.badLevel()) {
            effects = settings.badEffects();
        } else if (level >= settings.warningLevel()) {
            effects = settings.warningEffects();
        } else {
            return;
        }

        for (EffectSpec effect : effects) {
            player.addPotionEffect(effect.toPotionEffect(), true);
        }
    }

    private void startTask() {
        final OverdoseSettings settings = settings();
        if (!settings.enabled()) {
            return;
        }

        final long intervalTicks = Math.max(20L, settings.checkIntervalSeconds() * 20L);
        this.task = plugin.getServer().getScheduler().runTaskTimer(plugin, this::tickOnlinePlayers, intervalTicks, intervalTicks);
    }

    private void tickOnlinePlayers() {
        final OverdoseSettings settings = settings();
        if (!settings.enabled()) {
            return;
        }

        final long now = System.currentTimeMillis();
        boolean changed = false;
        for (Player player : plugin.getServer().getOnlinePlayers()) {
            final OverdoseProfile profile = profiles.get(player.getUniqueId());
            if (profile == null || profile.level() <= 0) {
                continue;
            }

            changed |= processDecay(player, profile, settings, now);
        }

        if (changed) {
            saveAll();
        }
    }

    private boolean processDecay(
            final Player player,
            final OverdoseProfile profile,
            final OverdoseSettings settings,
            final long now
    ) {
        if (!settings.decayEnabled() || profile.lastUseMillis() <= 0L) {
            return false;
        }

        if (now - profile.lastUseMillis() < secondsToMillis(settings.decayStartAfterSeconds())) {
            return false;
        }

        if (now - profile.lastDecayMillis() < secondsToMillis(settings.decayIntervalSeconds())) {
            return false;
        }

        final int previousLevel = profile.level();
        profile.decrease(settings.decayAmount());
        profile.setLastDecayMillis(now);

        if (previousLevel > 0 && profile.level() == 0) {
            profile.setLastUseMillis(0L);
            profile.setLastBadTripMillis(0L);
            plugin.getMessages().send(player, "overdose.recovered", placeholders(player, profile, 0, 0));
        }

        return previousLevel != profile.level();
    }

    private String thresholdMessage(final int previousLevel, final int currentLevel, final OverdoseSettings settings) {
        if (previousLevel < settings.criticalLevel() && currentLevel >= settings.criticalLevel()) {
            return "overdose.threshold-critical";
        }
        if (previousLevel < settings.badLevel() && currentLevel >= settings.badLevel()) {
            return "overdose.threshold-bad";
        }
        if (previousLevel < settings.warningLevel() && currentLevel >= settings.warningLevel()) {
            return "overdose.threshold-warning";
        }
        return null;
    }

    private OverdoseProfile profile(final UUID uniqueId) {
        return profiles.computeIfAbsent(uniqueId, OverdoseProfile::empty);
    }

    private Map<String, String> placeholders(
            final Player player,
            final OverdoseProfile profile,
            final int gain,
            final int decrease
    ) {
        final OverdoseSettings settings = settings();
        final Map<String, String> placeholders = new HashMap<>(plugin.getShopConfig().basePlaceholders());
        final int level = Math.max(0, Math.min(settings.maxLevel(), profile.level()));
        final int percent = (int) Math.round(level * 100.0D / settings.maxLevel());
        placeholders.put("player", player.getName());
        placeholders.put("overdose_level", String.valueOf(level));
        placeholders.put("overdose_max_level", String.valueOf(settings.maxLevel()));
        placeholders.put("overdose_percent", String.valueOf(percent));
        placeholders.put("overdose_gain", String.valueOf(Math.max(0, gain)));
        placeholders.put("overdose_decrease", String.valueOf(Math.max(0, decrease)));
        placeholders.put("overdose_stage", stageName(level, settings));
        placeholders.put("overdose_time_since_last_use", formatSince(profile.lastUseMillis()));
        return placeholders;
    }

    private String stageName(final int level, final OverdoseSettings settings) {
        if (level <= 0) {
            return plugin.getMessages().raw("overdose.stage.clean", "<green>нет передозировки</green>");
        }
        if (level >= settings.criticalLevel()) {
            return plugin.getMessages().raw("overdose.stage.critical", "<dark_red>критическая</dark_red>");
        }
        if (level >= settings.badLevel()) {
            return plugin.getMessages().raw("overdose.stage.bad", "<red>тяжёлая</red>");
        }
        if (level >= settings.warningLevel()) {
            return plugin.getMessages().raw("overdose.stage.warning", "<yellow>опасная</yellow>");
        }
        return plugin.getMessages().raw("overdose.stage.low", "<gray>низкая</gray>");
    }

    private String formatSince(final long timestampMillis) {
        if (timestampMillis <= 0L) {
            return "-";
        }
        final long seconds = Math.max(0L, (System.currentTimeMillis() - timestampMillis) / MILLIS_PER_SECOND);
        if (seconds < 60L) {
            return seconds + " сек.";
        }
        final long minutes = seconds / 60L;
        final long remainingSeconds = seconds % 60L;
        if (minutes < 60L) {
            return minutes + " мин. " + remainingSeconds + " сек.";
        }
        final long hours = minutes / 60L;
        final long remainingMinutes = minutes % 60L;
        return hours + " ч. " + remainingMinutes + " мин.";
    }

    private long secondsToMillis(final int seconds) {
        return Math.max(1, seconds) * MILLIS_PER_SECOND;
    }

    private OverdoseSettings settings() {
        return plugin.getShopConfig().overdose();
    }

    private void loadAll() {
        if (!dataFile.exists()) {
            return;
        }

        final YamlConfiguration data = YamlConfiguration.loadConfiguration(dataFile);
        final ConfigurationSection playersSection = data.getConfigurationSection("players");
        if (playersSection == null) {
            return;
        }

        for (String rawUniqueId : playersSection.getKeys(false)) {
            final UUID uniqueId;
            try {
                uniqueId = UUID.fromString(rawUniqueId);
            } catch (IllegalArgumentException ignored) {
                plugin.getLogger().warning("Invalid UUID in overdoses.yml: " + rawUniqueId);
                continue;
            }

            final String path = "players." + rawUniqueId;
            profiles.put(uniqueId, new OverdoseProfile(
                    uniqueId,
                    data.getInt(path + ".level", 0),
                    data.getLong(path + ".last-use", 0L),
                    data.getLong(path + ".last-decay", 0L),
                    data.getLong(path + ".last-badtrip", 0L)
            ));
        }
    }

    private void saveAll() {
        final YamlConfiguration data = new YamlConfiguration();
        for (OverdoseProfile profile : profiles.values()) {
            if (profile.level() <= 0 && profile.lastUseMillis() <= 0L) {
                continue;
            }

            final String path = "players." + profile.uniqueId();
            data.set(path + ".level", Math.max(0, Math.min(settings().maxLevel(), profile.level())));
            data.set(path + ".last-use", profile.lastUseMillis());
            data.set(path + ".last-decay", profile.lastDecayMillis());
            data.set(path + ".last-badtrip", profile.lastBadTripMillis());
        }

        try {
            data.save(dataFile);
        } catch (IOException exception) {
            plugin.getLogger().severe("Could not save overdoses.yml: " + exception.getMessage());
        }
    }
}

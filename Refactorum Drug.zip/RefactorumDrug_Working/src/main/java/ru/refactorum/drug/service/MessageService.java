package ru.refactorum.drug.service;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import ru.refactorum.drug.RefactorumDrugPlugin;

import java.io.File;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public final class MessageService {

    private final RefactorumDrugPlugin plugin;
    private final MiniMessage miniMessage;
    private final YamlConfiguration messages;

    public MessageService(final RefactorumDrugPlugin plugin) {
        this.plugin = Objects.requireNonNull(plugin, "plugin");
        this.miniMessage = MiniMessage.miniMessage();
        this.messages = YamlConfiguration.loadConfiguration(new File(plugin.getDataFolder(), "messages.yml"));
    }

    public Component component(final String path) {
        return component(path, Collections.emptyMap());
    }

    public Component component(final String path, final Map<String, String> placeholders) {
        final String fallback = "<red>Missing message: " + path + "</red>";
        final String raw = messages.getString(path, fallback);
        return deserialize(raw, placeholders);
    }

    public Component deserialize(final String rawText) {
        return deserialize(rawText, Collections.emptyMap());
    }

    public Component deserialize(final String rawText, final Map<String, String> placeholders) {
        final String raw = rawText == null ? "" : rawText;
        return miniMessage.deserialize(translateLegacyColors(applyPlaceholders(raw, placeholders)));
    }

    public String raw(final String path, final String fallback) {
        return messages.getString(path, fallback);
    }

    public List<Component> deserializeList(final List<String> rawLines, final Map<String, String> placeholders) {
        return rawLines.stream()
                .map(line -> deserialize(line, placeholders))
                .toList();
    }

    public void send(final CommandSender sender, final String path) {
        send(sender, path, Collections.emptyMap());
    }

    public void send(final CommandSender sender, final String path, final Map<String, String> placeholders) {
        sender.sendMessage(component(path, placeholders));
    }

    public String applyPlaceholders(final String rawText, final Map<String, String> placeholders) {
        final Map<String, String> merged = new HashMap<>();
        merged.put("prefix", messages.getString("prefix", ""));
        if (placeholders != null) {
            merged.putAll(placeholders);
        }

        String result = rawText == null ? "" : rawText;
        for (Map.Entry<String, String> entry : merged.entrySet()) {
            result = result.replace("{" + entry.getKey() + "}", entry.getValue() == null ? "" : entry.getValue());
        }
        return result;
    }

    private String translateLegacyColors(final String input) {
        final StringBuilder builder = new StringBuilder(input.length());
        for (int index = 0; index < input.length(); index++) {
            final char current = input.charAt(index);
            if ((current == '&' || current == '§') && index + 1 < input.length()) {
                final String tag = legacyTag(Character.toLowerCase(input.charAt(index + 1)));
                if (tag != null) {
                    builder.append(tag);
                    index++;
                    continue;
                }
            }
            builder.append(current);
        }
        return builder.toString();
    }

    private String legacyTag(final char code) {
        return switch (code) {
            case '0' -> "<reset><black>";
            case '1' -> "<reset><dark_blue>";
            case '2' -> "<reset><dark_green>";
            case '3' -> "<reset><dark_aqua>";
            case '4' -> "<reset><dark_red>";
            case '5' -> "<reset><dark_purple>";
            case '6' -> "<reset><gold>";
            case '7' -> "<reset><gray>";
            case '8' -> "<reset><dark_gray>";
            case '9' -> "<reset><blue>";
            case 'a' -> "<reset><green>";
            case 'b' -> "<reset><aqua>";
            case 'c' -> "<reset><red>";
            case 'd' -> "<reset><light_purple>";
            case 'e' -> "<reset><yellow>";
            case 'f' -> "<reset><white>";
            case 'k' -> "<obfuscated>";
            case 'l' -> "<bold>";
            case 'm' -> "<strikethrough>";
            case 'n' -> "<underlined>";
            case 'o' -> "<italic>";
            case 'r' -> "<reset>";
            default -> null;
        };
    }

    public RefactorumDrugPlugin plugin() {
        return plugin;
    }
}

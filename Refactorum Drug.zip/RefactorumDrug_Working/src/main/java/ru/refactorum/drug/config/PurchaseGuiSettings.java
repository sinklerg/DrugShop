package ru.refactorum.drug.config;

public final class PurchaseGuiSettings {

    private final int size;
    private final String title;
    private final int previewSlot;
    private final boolean closeAfterBuy;
    private final boolean fillEnabled;
    private final ConfigItem fillItem;
    private final ButtonConfig confirmButton;
    private final ButtonConfig backButton;

    public PurchaseGuiSettings(
            final int size,
            final String title,
            final int previewSlot,
            final boolean closeAfterBuy,
            final boolean fillEnabled,
            final ConfigItem fillItem,
            final ButtonConfig confirmButton,
            final ButtonConfig backButton
    ) {
        this.size = size;
        this.title = title;
        this.previewSlot = previewSlot;
        this.closeAfterBuy = closeAfterBuy;
        this.fillEnabled = fillEnabled;
        this.fillItem = fillItem;
        this.confirmButton = confirmButton;
        this.backButton = backButton;
    }

    public int size() {
        return size;
    }

    public String title() {
        return title;
    }

    public int previewSlot() {
        return previewSlot;
    }

    public boolean closeAfterBuy() {
        return closeAfterBuy;
    }

    public boolean fillEnabled() {
        return fillEnabled;
    }

    public ConfigItem fillItem() {
        return fillItem;
    }

    public ButtonConfig confirmButton() {
        return confirmButton;
    }

    public ButtonConfig backButton() {
        return backButton;
    }
}

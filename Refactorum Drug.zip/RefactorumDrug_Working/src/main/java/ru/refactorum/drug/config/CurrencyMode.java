package ru.refactorum.drug.config;

import java.util.Locale;

public enum CurrencyMode {
    ITEM,
    VAULT;

    public static CurrencyMode fromName(final String raw) {
        if (raw == null || raw.isBlank()) {
            return ITEM;
        }

        try {
            return CurrencyMode.valueOf(raw.trim().toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException ignored) {
            return ITEM;
        }
    }
}

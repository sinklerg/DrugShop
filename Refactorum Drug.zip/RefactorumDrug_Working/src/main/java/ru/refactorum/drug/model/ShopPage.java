package ru.refactorum.drug.model;

public final class ShopPage {

    private final String id;
    private final int order;
    private final String title;

    public ShopPage(final String id, final int order, final String title) {
        this.id = id;
        this.order = order;
        this.title = title == null ? id : title;
    }

    public String id() {
        return id;
    }

    public int order() {
        return order;
    }

    public String title() {
        return title;
    }
}

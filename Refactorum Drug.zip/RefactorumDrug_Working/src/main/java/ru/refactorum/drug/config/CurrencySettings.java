package ru.refactorum.drug.config;

import org.bukkit.Material;

public record CurrencySettings(
        CurrencyMode mode,
        String displayName,
        Material itemMaterial,
        boolean itemRequireCustomModelData,
        int itemCustomModelData,
        String amountFormat,
        boolean useVaultFormat
) {
    public boolean vaultMode() {
        return mode == CurrencyMode.VAULT;
    }

    public boolean itemMode() {
        return mode == CurrencyMode.ITEM;
    }
}

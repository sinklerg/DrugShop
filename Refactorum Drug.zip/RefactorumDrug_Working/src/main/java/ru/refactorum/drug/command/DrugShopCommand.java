package ru.refactorum.drug.command;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.command.TabCompleter;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import ru.refactorum.drug.RefactorumDrugPlugin;
import ru.refactorum.drug.model.ShopPage;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;

public final class DrugShopCommand implements CommandExecutor, TabCompleter {

    private final RefactorumDrugPlugin plugin;

    public DrugShopCommand(final RefactorumDrugPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(
            final @NotNull CommandSender sender,
            final @NotNull Command command,
            final @NotNull String label,
            final @NotNull String[] args
    ) {
        if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
            return handleReload(sender);
        }

        if (args.length > 0 && args[0].equalsIgnoreCase("addiction")) {
            return handleAddiction(sender, args);
        }

        if (!(sender instanceof Player player)) {
            plugin.getMessages().send(sender, "command.player-only");
            return true;
        }

        if (!hasUsePermission(player)) {
            plugin.getMessages().send(player, "command.no-permission");
            return true;
        }

        final Optional<Integer> resolvedPage = resolvePage(args.length > 0 ? args[0] : null);
        if (resolvedPage.isEmpty()) {
            plugin.getMessages().send(player, "shop.invalid-page");
            return true;
        }

        plugin.getShopMenuService().openShop(player, resolvedPage.get());
        return true;
    }

    private boolean handleAddiction(final CommandSender sender, final String[] args) {
        if (args.length >= 2 && args[1].equalsIgnoreCase("reset")) {
            return handleAddictionReset(sender, args);
        }

        if (args.length >= 2 && args[1].equalsIgnoreCase("set")) {
            return handleAddictionSet(sender, args);
        }

        if (args.length >= 2) {
            if (!hasAdminPermission(sender)) {
                plugin.getMessages().send(sender, "command.no-permission");
                return true;
            }

            final Player target = plugin.getServer().getPlayerExact(args[1]);
            if (target == null) {
                plugin.getMessages().send(sender, "command.player-not-found", Map.of("player", args[1]));
                return true;
            }

            plugin.getAddictionService().sendStatus(sender, target, true);
            return true;
        }

        if (!(sender instanceof Player player)) {
            plugin.getMessages().send(sender, "command.player-only");
            return true;
        }

        if (!hasUsePermission(player)) {
            plugin.getMessages().send(player, "command.no-permission");
            return true;
        }

        plugin.getAddictionService().sendStatus(player, player, false);
        return true;
    }

    private boolean handleAddictionReset(final CommandSender sender, final String[] args) {
        if (!hasAdminPermission(sender)) {
            plugin.getMessages().send(sender, "command.no-permission");
            return true;
        }

        if (args.length < 3) {
            plugin.getMessages().send(sender, "command.usage");
            return true;
        }

        final Player target = plugin.getServer().getPlayerExact(args[2]);
        if (target == null) {
            plugin.getMessages().send(sender, "command.player-not-found", Map.of("player", args[2]));
            return true;
        }

        plugin.getAddictionService().reset(target);
        plugin.getMessages().send(sender, "addiction.reset-admin", Map.of("player", target.getName()));
        plugin.getMessages().send(target, "addiction.reset-target");
        return true;
    }

    private boolean handleAddictionSet(final CommandSender sender, final String[] args) {
        if (!hasAdminPermission(sender)) {
            plugin.getMessages().send(sender, "command.no-permission");
            return true;
        }

        if (args.length < 4) {
            plugin.getMessages().send(sender, "command.usage");
            return true;
        }

        final Player target = plugin.getServer().getPlayerExact(args[2]);
        if (target == null) {
            plugin.getMessages().send(sender, "command.player-not-found", Map.of("player", args[2]));
            return true;
        }

        final Optional<Integer> parsedLevel = parseInteger(args[3]);
        if (parsedLevel.isEmpty()) {
            plugin.getMessages().send(sender, "command.invalid-number", Map.of("value", args[3]));
            return true;
        }

        final int level = plugin.getAddictionService().setLevel(target, parsedLevel.get());
        final Map<String, String> placeholders = Map.of(
                "player", target.getName(),
                "level", String.valueOf(level),
                "max_level", String.valueOf(plugin.getShopConfig().addiction().maxLevel())
        );
        plugin.getMessages().send(sender, "addiction.set-admin", placeholders);
        plugin.getMessages().send(target, "addiction.set-target", placeholders);
        return true;
    }

    private boolean handleReload(final CommandSender sender) {
        if (!hasAdminPermission(sender)) {
            plugin.getMessages().send(sender, "command.no-permission");
            return true;
        }

        plugin.reloadLocalData();
        plugin.getMessages().send(sender, "command.reloaded", Map.of(
                "pages", String.valueOf(plugin.getShopConfig().pages().size()),
                "substances", String.valueOf(plugin.getShopConfig().substancesById().size()),
                "remedies", String.valueOf(plugin.getShopConfig().remediesById().size())
        ));
        return true;
    }

    private boolean hasUsePermission(final Player player) {
        final String usePermission = plugin.getShopConfig().usePermission();
        return usePermission.isBlank() || player.hasPermission(usePermission);
    }

    private boolean hasAdminPermission(final CommandSender sender) {
        final String adminPermission = plugin.getShopConfig().adminPermission();
        return adminPermission.isBlank() || sender.hasPermission(adminPermission);
    }

    private Optional<Integer> resolvePage(final String rawPage) {
        if (rawPage == null || rawPage.isBlank()) {
            return Optional.of(1);
        }

        try {
            return Optional.of(Integer.parseInt(rawPage));
        } catch (NumberFormatException ignored) {
            return plugin.getShopConfig().pageNumberById(rawPage);
        }
    }

    private Optional<Integer> parseInteger(final String rawNumber) {
        if (rawNumber == null || rawNumber.isBlank()) {
            return Optional.empty();
        }

        try {
            return Optional.of(Integer.parseInt(rawNumber));
        } catch (NumberFormatException ignored) {
            return Optional.empty();
        }
    }

    @Override
    public @Nullable List<String> onTabComplete(
            final @NotNull CommandSender sender,
            final @NotNull Command command,
            final @NotNull String alias,
            final @NotNull String[] args
    ) {
        if (args.length == 1) {
            final List<String> options = new ArrayList<>();
            options.add("addiction");
            if (hasAdminPermission(sender)) {
                options.add("reload");
            }

            for (int index = 0; index < plugin.getShopConfig().pages().size(); index++) {
                final ShopPage page = plugin.getShopConfig().pages().get(index);
                options.add(String.valueOf(index + 1));
                options.add(page.id());
            }

            return filter(args[0], options);
        }

        if (args.length == 2 && args[0].equalsIgnoreCase("addiction")) {
            final List<String> options = new ArrayList<>();
            if (hasAdminPermission(sender)) {
                options.add("reset");
                options.add("set");
                plugin.getServer().getOnlinePlayers().forEach(player -> options.add(player.getName()));
            }
            return filter(args[1], options);
        }

        if (args.length == 3
                && args[0].equalsIgnoreCase("addiction")
                && (args[1].equalsIgnoreCase("reset") || args[1].equalsIgnoreCase("set"))
                && hasAdminPermission(sender)) {
            final List<String> options = plugin.getServer().getOnlinePlayers().stream()
                    .map(Player::getName)
                    .toList();
            return filter(args[2], options);
        }

        if (args.length == 4
                && args[0].equalsIgnoreCase("addiction")
                && args[1].equalsIgnoreCase("set")
                && hasAdminPermission(sender)) {
            final List<String> options = List.of("0", "25", "50", "75", "100");
            return filter(args[3], options);
        }

        return List.of();
    }

    private List<String> filter(final String token, final List<String> options) {
        final String lowerToken = token.toLowerCase(Locale.ROOT);
        return options.stream()
                .filter(option -> option.toLowerCase(Locale.ROOT).startsWith(lowerToken))
                .sorted()
                .toList();
    }
}
